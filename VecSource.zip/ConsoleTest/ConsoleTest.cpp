﻿/*
题目：主线程创建两个辅助线程，辅助线程1使用选择排序算法对数组的前半部分排序，辅助线程2使用选择排序算法对数组的后半部分排序，主线程等待辅助线程运行結束后,使用归并排序算法归并子线程的计算结果
开发工具：DEV windows平台
语言：C++
*/
#include <windows.h>
#include <iostream>
using namespace std;

#define MAX 100   //数组空间最大值

int array_test[MAX];   //待排序的数组

typedef struct param {    //作为线程参数传入的结构体
    int* array;
    int start, end;
}param;

void swap(int* a, int* b)   //选择排序中用到的交换函数
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

DWORD WINAPI ThreadProc(LPVOID lpParameter)   //线程的回调函数
{   //进行选择排序
    param* p;
    p = (param*)lpParameter;  //将线程参数强制转化为所需类型
    int l = p->start, r = p->end;
    if (l >= r) return NULL;

    for (int i = l; i < r; i++)
    {
        int min = i;
        for (int j = i + 1; j <= r; j++)
            if (p->array[j] < p->array[min])
                min = j;
        swap(&p->array[min], &p->array[i]);
    }
    return 0L;
}

int main()
{
    int n;
    //处理输入、初始化
    cout << "please enter the length of the array:";
    cin >> n;
    cout << "please enter the element of the array:";
    for (int i = 0; i < n; i++) cin >> array_test[i];

    HANDLE sortq, sorth;

    int mid = (0 + n - 1) >> 1;
    //sortq
    param paramq;
    paramq.array = array_test;
    paramq.start = 0;             //[
    paramq.end = mid;             //]
    sortq = CreateThread(NULL, 0, ThreadProc, &paramq, 0, NULL);   //创建线程，传入参数
    param paramk[2];
    //sorth
    param paramh;
    paramh.array = array_test;
    paramh.start = mid + 1;         //[
    paramh.end = n - 1;             //]
    sorth = CreateThread(NULL, 0, ThreadProc, &paramh, 0, NULL);   //创建线程，传入参数

    WaitForSingleObject(sortq, INFINITE);   //等待线程执行结束返回主线程
    WaitForSingleObject(sorth, INFINITE);   //等待线程执行结束返回主线程

    //主线程进行归并排序 
    int k = 0, i = 0, j = mid + 1;
    int temp[MAX];
    while (i <= mid && j <= n - 1)
    {
        if (array_test[i] < array_test[j]) temp[k++] = array_test[i++];
        else temp[k++] = array_test[j++];
    }
    while (i <= mid) temp[k++] = array_test[i++];
    while (j <= n - 1) temp[k++] = array_test[j++];

    for (int i = 0, j = 0; j <= n - 1; j++, i++) array_test[j] = temp[i];

    for (int i = 0; i < n; i++) printf("%d ", array_test[i]);
    printf("\n");
    return 0;
}
