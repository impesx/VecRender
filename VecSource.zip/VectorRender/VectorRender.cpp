﻿#define _CRT_SECURE_NO_WARNINGS
#define PI 3.1415926
#include "E512W3DWindow.hpp"
E512W3DWindowManager e512w3d;
Mesh model;
E512W3DWindow w, wr;
Object3D a, b;
Object3D camera_l, camera_r;
int rotate = 0;
int written = 1;
int dual = 1;
int view_width = 400;
int view_height = 400;
float max_vertex = 0;
float min_vertex = 0;
float base_scale;
int refresh = 1; //
float theta = 0, phi = 0;
float onMouseDownTheta, onMouseDownPhi;
int onMouseDownLX, onMouseDownLY, onMouseDownRX, onMouseDownRY;
bool cameraRotating = 0;
bool cameraPanning = 0;



std::wstring getExecutablePath() {
	WCHAR buffer[MAX_PATH];
	GetModuleFileName(NULL, buffer, MAX_PATH);
	std::wstring::size_type pos = std::wstring(buffer).find_last_of(L"\\/");
	return std::wstring(buffer).substr(0, pos);
}
//std::string file_path = "./3D_Files/J20.obj";
std::string file_path = "3D_Files/model.obj";
//std::string file_path = "model.obj";

//std::string file_path = "C:/Users/PES/source/repos/Vec/x64/Debug/3D_Files/model.obj";
//std::string file_path = "C:/Users/PES/source/repos/Vec/x64/Debug/3D_Files/RB26DETT.obj";
//std::string file_path = "./mac.obj";


void setup();
void loop();

#define WC_NAME TEXT("For Doria朵")
#define WT_NAME TEXT("矢量渲染引擎")


LRESULT CALLBACK proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
	switch (msg) {
	case WM_DESTROY:
	{
		PostQuitMessage(0);
		return 0;
	}
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hwnd, &ps);
		HBITMAP hBitmap = CreateBitmap(M5.width, M5.height, 1, 32, M5.pixels);
		HDC hBuffer = CreateCompatibleDC(hdc);
		SelectObject(hBuffer, hBitmap);
		BitBlt(hdc, 0, 0, M5.width, M5.height, hBuffer, 0, 0, SRCCOPY);
		DeleteDC(hBuffer);
		DeleteObject(hBitmap);
		EndPaint(hwnd, &ps);
		return 0;
	}
	case WM_KEYDOWN:
	{
		if (wp == 32)
			rotate = 1 - rotate;
		return 0;
	}
	case WM_LBUTTONDOWN:
	{
		int xPos = GET_X_LPARAM(lp);
		int yPos = GET_Y_LPARAM(lp);

		onMouseDownTheta = theta;
		onMouseDownPhi = phi;
		onMouseDownLX = xPos;
		onMouseDownLY = yPos;
		cameraRotating = 1;
		SetCapture(hwnd);


		//std::cout << xPos << "," << yPos << std::endl;
		//refresh = 1;
		return 0;
	}
	case WM_RBUTTONDOWN:
	{
		int xPos = GET_X_LPARAM(lp);
		int yPos = GET_Y_LPARAM(lp);
		onMouseDownRX = xPos;
		onMouseDownRY = yPos;
		cameraPanning = 1;
		SetCapture(hwnd);
		//std::cout << xPos << "," << yPos << std::endl;
		//refresh = 1;
		return 0;
	}
	case WM_LBUTTONUP:
	{
		cameraRotating = 0;
		ReleaseCapture();
		return 0;
	}
	case WM_RBUTTONUP:
	{
		cameraPanning = 0;
		ReleaseCapture();
		return 0;
	}

	
	case WM_MOUSEMOVE:
	{
		int xPos = GET_X_LPARAM(lp);
		int yPos = GET_Y_LPARAM(lp);
		if (cameraRotating) {
			theta = (xPos - onMouseDownLX) * (0.5) + onMouseDownTheta;
			phi = (yPos - onMouseDownLY) * (0.5) + onMouseDownPhi;
			//phi = min(90, max(-90, phi));
			float radius = 360;
			/*camera_l.position.x = radius * sin(theta * PI / 360) * cos(phi * PI / 360);
			camera_l.position.y = radius * sin(phi * PI / 360);
			camera_l.position.z = radius * cos(theta * PI / 360) * cos(phi * PI / 360);*/

			a.rotation.y = theta;
			a.rotation.x = phi;

			camera_l.rotation.x = -10;
			camera_l.position.y = 1;

			//a.rotation.y = radius * sin(theta * PI / 360.0) * cos(phi * PI / 360.0);
			//a.rotation.x = radius * sin(phi * PI / 360.0);
			////a.rotation.z = radius * cos(theta * PI / 360.0) * cos(phi * PI / 360.0);
			//std::cout << a.rotation.x << "," << a.rotation.y << std::endl;
			refresh = 1;
		}
		if (cameraPanning) {
			a.position.y += (yPos - onMouseDownRY) * (-0.001);
			a.position.x += (xPos - onMouseDownRX) * (0.001);

			refresh = 1;
		}


		
		
		return 0;
	}
	case WM_MOUSEWHEEL:
	{
		int delta = GET_WHEEL_DELTA_WPARAM(wp);
		if (delta > 0)
			a.scale = a.scale * (1 + 0.03 * (delta / 120));
		else
			a.scale = a.scale * (1 - 0.05 * (-delta / 120));

		refresh = 1;
		return 0;
	}
	}
	return DefWindowProc(hwnd, msg, wp, lp);
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, int nCmdShow) {
	HWND hwnd;
	MSG msg;
	WNDCLASS wc;
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = proc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = WC_NAME;
	if (!RegisterClass(&wc)) { return 0; }

	AllocConsole();
	freopen("CONOUT$", "w", stdout);
	freopen("CONIN$", "r+t", stdin);
	//std::wstring executablePath = getExecutablePath();
	//std::wstring file_path = executablePath + L"\\3D_Files\\model.obj";

	setup();

	hwnd = CreateWindow(
		WC_NAME, WT_NAME, (WS_OVERLAPPEDWINDOW | WS_VISIBLE) & ~WS_THICKFRAME & ~WS_MAXIMIZEBOX,
		100, 100, e512w3d.width * SUP_PIXEL + 6, e512w3d.height * SUP_PIXEL + 28 * 1,
		NULL, NULL, hInstance, NULL
	);
	if (hwnd == NULL) { return 0; }
	M5.window_app(hwnd, e512w3d.width * SUP_PIXEL, e512w3d.height * SUP_PIXEL);

	while (true) {
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
			if (msg.message == WM_QUIT) { break; }
			DispatchMessage(&msg);
		}
		else {
			loop();
			Sleep(1);
		}
	}
	return msg.wParam;
}









void render_init() {
	e512w3d.width = view_width * 2;
	e512w3d.height = view_height;
	w.width = e512w3d.width / 2;
	w.height = e512w3d.height;
	wr.width = e512w3d.width / 2;
	wr.height = e512w3d.height;
	wr.sx = e512w3d.width / 2;
	wr.bgcolor = w.bgcolor;
	a.scale = base_scale;
	std::cout << "Base_scale=" << a.scale.x << ".\n";
	a.mesh = &model;
	b.mesh = a.mesh;
	b.scale = a.scale;
	a.render_type = RenderType::PolygonNormal;
	a.color = M5.Lcd.color565(255, 255, 255);
	a.rotation.x = 0;
	b.render_type = RenderType::WireFrame;
	b.color = M5.Lcd.color565(255, 255, 255);
	b.rotation.x = 0;
	camera_l.position.z = 10;
	camera_r.position.z = camera_l.position.z;
	camera_l.position.y = 0;
	camera_r.position.y = 0;
	if (0) {
		camera_l.position.x = -1;
		camera_r.position.x = 1;
		camera_l.rotation.y = -4;
		camera_r.rotation.y = 4;
	}
	w.setCamera(camera_l);
	w.setDirectionalLight(-1, -1, -1);
	w.ambient = 0.8;
	w.addChild(a);
	wr.setCamera(camera_r);
	wr.setDirectionalLight(-1, -1, -1);
	wr.ambient = 0.8;
	wr.addChild(b);
	a.rotation.x = 0;
	a.rotation.y = 0;
	a.rotation.z = 0;
	e512w3d.add(w);
	if (dual) e512w3d.add(wr);
	e512w3d.begin();
}

void setup() {
	time_begin = millis();
	model.vertexs.reserve(2);
	model.faces.reserve(2);
	std::ifstream fin;
	fin.open(file_path, std::ios::in);
	if (!fin.is_open()) {
		std::cerr << "cannot open the file";
		while (1);
	}
	char buf[1021] = { 0 };
	while (fin.getline(buf, sizeof(buf))) {
		std::string head;
		std::stringstream line(buf);
		line >> head;
		if (head == "v") {
			float x, y, z;
			line >> x >> y >> z;
			Vector3 v(x, y, z);
			model.vertexs.emplace_back(v);
			max_vertex = max(max_vertex, x);
			max_vertex = max(max_vertex, y);
			max_vertex = max(max_vertex, z);
			min_vertex = min(min_vertex, x);
			min_vertex = min(min_vertex, y);
			min_vertex = min(min_vertex, z);
		}
		if (head == "f") {
			std::string a, b, c, d;
			int x, y, z;
			line >> a >> b >> c;
			int pos = a.find('/');
			if (pos != std::string::npos) {
				// 处理包含多个序号的数据：  f 1/2/3 2/3/1 3/4/5
				x = atoi(a.substr(0, pos).c_str());
			}
			else {
				x = atoi(a.c_str());
			}
			pos = b.find('/');
			if (pos != std::string::npos) {
				y = atoi(b.substr(0, pos).c_str());
			}
			else {
				y = atoi(b.c_str());
			}
			pos = c.find('/');
			if (pos != std::string::npos) {
				z = atoi(c.substr(0, pos).c_str());
			}
			else {
				z = atoi(c.c_str());
			}
			Face f(x - 1, y - 1, z - 1);
			model.faces.emplace_back(f);
		}
	}
	std::cout << "Mesh loaded. ";
	time_end = millis();
	std::cout << "Elapsed time: " << std::to_string((time_end - time_begin) / 1000.0) << "s\n";
	std::cout << "Vertex:" << std::to_string(model.vertexs.size()) << "   " << "Faces:"
		<< std::to_string(model.faces.size()) << "   ";
	/*std::cout << "\nGenerating edges...\n";
	for (int i = 0; i < model.faces.size(); i++) {
		if (i % 1000 == 0) std::cout << std::to_string(i / 1000) << "k ";
		model.addEdge(model.faces[i].a, model.faces[i].b, i);
		model.addEdge(model.faces[i].b, model.faces[i].c, i);
		model.addEdge(model.faces[i].c, model.faces[i].a, i);
	}
	std::cout << "\nEdges loaded.\n";*/
	base_scale = 15 / (3.5 * (max_vertex - min_vertex));
	cosCrease = cos(3.14 * CreaseAngle / 180.f);
	render_init();
	//    e512w3d.draw();
}
void has_input() {
	refresh = 0;
	std::string head;
	float var1;
	std::cin >> head;
	if (head == "exit") exit(0);
	else if (head == "svg") written = 0;
	else if (head == "r") rotate = 1 - rotate;
	else if (head == "o") {
		w.isortho = 1 - w.isortho;
		refresh = 1;
	}
	else if (head == "e") {
		std::cout << "Generating edges...\n";
		time_begin = millis();
		for (int i = 0; i < model.faces.size(); i++) {
			if (i % 1000 == 0) std::cout << std::to_string(i / 1000) << "k ";
			model.addEdge(model.faces[i].a, model.faces[i].b, i);
			model.addEdge(model.faces[i].b, model.faces[i].c, i);
			model.addEdge(model.faces[i].c, model.faces[i].a, i);
		}
		std::cout << "\nEdges loaded. ";
		std::cout << "\nEdges count: " << model.edges.size();
		time_end = millis();
		std::cout << " Elapsed time: " << std::to_string((time_end - time_begin) / 1000.0) << "s\n";
	}
	else if (head == "output") {
		std::cout << "Generating edges...\n";
		time_begin = millis();
		for (int i = 0; i < model.faces.size(); i++) {
			if (i % 1000 == 0) std::cout << std::to_string(i / 1000) << "k ";
			model.addEdge(model.faces[i].a, model.faces[i].b, i);
			model.addEdge(model.faces[i].b, model.faces[i].c, i);
			model.addEdge(model.faces[i].c, model.faces[i].a, i);
		}
		std::cout << "\nEdges loaded. ";
		time_end = millis();
		std::cout << "Elapsed time: " << std::to_string((time_end - time_begin) / 1000.0) << "s\n";
		a.render_type = RenderType::EdgesZ;
		e512w3d.draw();
		written = 0;
	}
	else {
		std::cin >> var1;
		if (head == "r:") rotate = (int)var1;
		if (head == "t") {
			a.render_type = (int)var1;
			refresh = 1;
		}
		if (head == "s") {
			a.scale = base_scale * var1;
			b.scale = a.scale;
			std::cout << "Scale=" << a.scale.x << ".\n";
			refresh = 1;
		}
		if (head == "c") {
			CreaseAngle = var1;
			cosCrease = cos(3.14 * CreaseAngle / 180.f);
			refresh = 1;
		}
		if (head == "rx") {
			a.rotation.x = var1;
			refresh = 1;
		}
		if (head == "ry") {
			a.rotation.y = var1;
			refresh = 1;
		}
		if (head == "rz") {
			a.rotation.z = var1;
			refresh = 1;
		}
		if (head == "cz") {
			camera_l.position.z = var1;
			refresh = 1;
		}
		if (head == "x") {
			a.position.x = var1;
			refresh = 1;
		}
		if (head == "y") {
			a.position.y = var1;
			refresh = 1;
		}
		if (head == "z") {
			a.position.z = var1;
			refresh = 1;
		}
	}
}
void loop() {
	if (_kbhit()) {
		has_input();
	}
	if (!written) {
		FILE* fp = NULL;
		fp = fopen("./export.svg", "w+");
		std::string out = "";
		std::string w = std::to_string(view_width);
		std::string h = std::to_string(view_height);
		char temp[100];
		out += "<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" viewBox=\"0 0 " + w + " " + h +
			"\" width=\"" + w + "\" height=\"" + h + "\">\n";
		out += "<rect width=\"" + w + "\" height=\"" + h + "\" fill=\"rgb(0, 65, 186)\" />\n";
		out += "<g stroke=\"white\" stroke-width=\"0.05\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n";
		out += svg_lines_down8;
		out += "</g>\n";
		out += "<g stroke=\"white\" stroke-width=\"0.05\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n";
		out += svg_lines_down7;
		out += "</g>\n";
		out += "<g stroke=\"white\" stroke-width=\"0.05\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n";
		out += svg_lines_down6;
		out += "</g>\n";
		out += "<g stroke=\"white\" stroke-width=\"0.05\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n";
		out += svg_lines_down5;
		out += "</g>\n";
		out += "<g stroke=\"white\" stroke-width=\"0.05\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n";
		out += svg_lines_down4;
		out += "</g>\n";
		out += "<g stroke=\"white\" stroke-width=\"0.05\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n";
		out += svg_lines_down3;
		out += "</g>\n";
		out += "<g stroke=\"white\" stroke-width=\"0.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n";
		out += svg_lines_down2;
		out += "</g>\n";
		out += "<g stroke=\"white\" stroke-width=\"0.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n";
		out += svg_lines_down1;
		out += "</g>\n";
		out += "<g stroke=\"white\" stroke-width=\"0.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n";
		out += svg_lines_up;
		out += "</g>\n";
		out += "<g stroke=\"white\" stroke-width=\"0.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n";
		out += svg_lines_top;
		out += "</g>\n</svg>\n";
		fprintf(fp, out.c_str());
		fclose(fp);
		written = 1;
		std::cout << "SVG saved.\n";
	}
	if (rotate) {
		a.rotation.y += 2.22f; // y
		a.rotation.y = fmod(a.rotation.y, 360);
		a.rotation.x += 1.1f;
		a.rotation.x = fmod(a.rotation.x, 360);
		a.rotation.z += 0.31f;
		a.rotation.z = fmod(a.rotation.z, 360);
		//            printf("rx=%.16f,y=%.16f,z=%.16f\n", a.rotation.x, a.rotation.y, a.rotation.z);
		refresh = 1;
	}
	b.rotation.x = a.rotation.x;
	b.rotation.y = a.rotation.y;
	b.rotation.z = a.rotation.z;
	b.position.x = a.position.x;
	b.position.y = a.position.y;
	b.position.z = a.position.z;
	camera_r.position.z = camera_l.position.z;
	if (refresh) e512w3d.draw();
	refresh = 0;

}

