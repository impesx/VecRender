/*
/   改动：增加vertex渲染类型；增加vertexz渲染类型; polygonnormal中cross(v1-v0, v2-v0)改为cross(v1-v0, v2-v1)
/
/
*/
#pragma once

#include "E512W3DUtils.hpp"

#ifdef DOUBLE
#define EPSINON 1e-6
#else
#define EPSINON 8e-5
#endif
#define SHOW_INTER 0
struct Segment {
	Vector2 a;
	Vector2 b;
	Segment() { a = 0; b = 0; }
	Segment(Vector2 p1, Vector2 p2) { a = p1; b = p2; }
};

struct param {    //作为线程参数传入的结构体
	int thread_num; //线程总个数
	int thread_index;//此线程的序号
	Object3D* o;
	E512Array<Vector3>* v;
	std::string* lines_top; //记录线段svg信息的字符串地址
	std::string* lines_up;
	std::string* lines_down1;
	std::string* lines_down2;
	std::string* lines_down3;
	std::string* lines_down4;
	std::string* lines_down5;
	std::string* lines_down6;
	std::string* lines_down7;
	std::string* lines_down8;
	E512Array<Segment>* top;
	E512Array<Segment>* up;
	E512Array<Segment>* down;
	//结构体数组定义时可以不要构造函数
};

DWORD WINAPI DrawEdgeThread(LPVOID lpParameter)   //线程的回调函数
{
	param* p;
	p = (param*)lpParameter;  //将线程参数强制转化为所需类型
	Object3D* o = p->o;
	E512Array<Vector3>& v = *p->v;
	std::string& svg_lines_top = *p->lines_top;
	std::string& svg_lines_up = *p->lines_up;
	std::string& svg_lines_down1 = *p->lines_down1;
	std::string& svg_lines_down2 = *p->lines_down2;
	std::string& svg_lines_down3 = *p->lines_down3;
	std::string& svg_lines_down4 = *p->lines_down4;
	std::string& svg_lines_down5 = *p->lines_down5;
	std::string& svg_lines_down6 = *p->lines_down6;
	std::string& svg_lines_down7 = *p->lines_down7;
	std::string& svg_lines_down8 = *p->lines_down8;
	E512Array<Segment>& top = *p->top;
	E512Array<Segment>& up = *p->up;
	E512Array<Segment>& down = *p->down;

	//int time_begin = millis();
	svg_lines_top = "";
	svg_lines_up = "";
	svg_lines_down1 = "";
	svg_lines_down2 = "";
	svg_lines_down3 = "";
	svg_lines_down4 = "";
	svg_lines_down5 = "";
	svg_lines_down6 = "";
	svg_lines_down7 = "";
	svg_lines_down8 = "";
	char temp[100];

	for (uint32_t e = p->thread_index; e < o->mesh->edges.size(); e += p->thread_num) {

		if (e % 10000 == 0) std::cout << "|";
		else if (e % 1000 == 0) std::cout << ".";

		if (o->mesh->edges[e].edge_type == EdgeType::Normal) continue;
		Vector3 a = v[o->mesh->edges[e].va];
		Vector3 b = v[o->mesh->edges[e].vb];
		E512Array<Vector2> InterSet; //交点坐标序列
		E512Array<double>  InterZ;//交点z序列
		for (uint32_t e1 = 0; e1 < o->mesh->edges.size(); e1++) {
			if (o->mesh->edges[e1].edge_type == EdgeType::Normal) continue;
			if (e1 == e) continue;
			Vector3 c = v[o->mesh->edges[e1].va];
			Vector3 d = v[o->mesh->edges[e1].vb];
			if (min(a.x, b.x) > max(c.x, d.x) ||
				min(c.x, d.x) > max(a.x, b.x) ||
				min(a.y, b.y) > max(c.y, d.y) ||
				min(c.y, d.y) > max(a.y, b.y)) continue; //未通过快速排斥检验
			double area_abc = (a.x - c.x) * (b.y - c.y) - (a.y - c.y) * (b.x - c.x);
			double area_abd = (a.x - d.x) * (b.y - d.y) - (a.y - d.y) * (b.x - d.x);
			if (area_abc * area_abd >= -EPSINON) continue; //三角形面积判据
			double area_cda = (c.x - a.x) * (d.y - a.y) - (c.y - a.y) * (d.x - a.x);
			double area_cdb = area_cda + area_abc - area_abd;// 三角形cdb 面积可用其他三个三角形的面积求得，这里考虑了各个三角形面积的正负号
			if (area_cda * area_cdb >= -EPSINON) continue;
			//确认有交点
			Vector2 intersection;
			double intersection_z = 0;
			double intersection_1_z = 0;
			double t0 = area_cda / (area_abd - area_abc); //交点在原edge上的参数
			double t1 = -area_abc / (area_abd - area_abc);//交点在待比较edge上的参数
			double dx = t0 * (b.x - a.x);
			double dy = t0 * (b.y - a.y);
			double dz = t0 * (b.z - a.z);
			double dz1 = t1 * (d.z - c.z);
			intersection.x = a.x + dx;
			intersection.y = a.y + dy;
			intersection_z = a.z + dz;
			intersection_1_z = c.z + dz1;
			/*           if (SHOW_INTER)
						   drawBuffLineSDF(intersection.x, intersection.y, intersection.x + 0.1, intersection.y + 0.1, 2, color565(255, 255, 255));*/
						   //                this->buff->pushSprite(0, 0);
			//插入并排序该交点
			InterSet.emplace_back(intersection);
			InterZ.emplace_back(intersection_z);
			int i;
			for (i = InterSet.size() - 2; i >= 0; i--) {
				if (InterSet[i].x > intersection.x || ((InterSet[i].x == intersection.x) && (InterSet[i].y > intersection.y))) {
					InterSet[i + 1] = InterSet[i];
					InterZ[i + 1] = InterZ[i];
				}
				else break;
			}
			InterSet[i + 1] = intersection;
			InterZ[i + 1] = intersection_z;
		}
		//判断处理端点a
		Vector2 intersection = a.head();
		double intersection_z = a.z;
		//插入并排序该点a
		InterSet.emplace_back(intersection);
		InterZ.emplace_back(intersection_z);
		int i;
		for (i = InterSet.size() - 2; i >= 0; i--) {
			if (InterSet[i].x > intersection.x || ((InterSet[i].x == intersection.x) && (InterSet[i].y > intersection.y))) {
				InterSet[i + 1] = InterSet[i];
				InterZ[i + 1] = InterZ[i];
			}
			else break;
		}
		InterSet[i + 1] = intersection;
		InterZ[i + 1] = intersection_z;
		//判断处理端点b
		intersection = b.head();
		intersection_z = b.z;
		//插入并排序该点b
		InterSet.emplace_back(intersection);
		InterZ.emplace_back(intersection_z);
		for (i = InterSet.size() - 2; i >= 0; i--) {
			if (InterSet[i].x > intersection.x || ((InterSet[i].x == intersection.x) && (InterSet[i].y > intersection.y))) {
				InterSet[i + 1] = InterSet[i];
				InterZ[i + 1] = InterZ[i];
			}
			else break;
		}
		InterSet[i + 1] = intersection;
		InterZ[i + 1] = intersection_z;

		//至此，该edge已被细分为若干线段（segment)，可根据各线段类型作图了
		for (uint32_t index = 0; (index + 1) < InterSet.size(); index++) {
			Vector2 p1 = InterSet[index];
			Vector2 p2 = InterSet[index + 1];
			intersection_z = (InterZ[index] + InterZ[index + 1]) / 2.0;
			uint8_t Seg_Type = 0;
			intersection.x = (p1.x + p2.x) / 2.0;
			intersection.y = (p1.y + p2.y) / 2.0;
			Seg_Type = 0;//先假设为top（0）

			for (uint32_t fi = 0; fi < o->mesh->faces.size(); fi++) {
				Face& f = o->mesh->faces[fi];
				Vector3& v1 = v[f.a];
				Vector3& v2 = v[f.b];
				Vector3& v3 = v[f.c];
				if (intersection.x < min(v1.x, min(v2.x, v3.x)) ||
					intersection.y < min(v1.y, min(v2.y, v3.y)) ||
					intersection.x > max(v1.x, max(v2.x, v3.x)) ||
					intersection.y > max(v1.y, max(v2.y, v3.y)))
					continue; //点在三角形AABB之外
				Vector2 P = intersection;
				Vector2 AP = P - v1.head();
				Vector2 BP = P - v2.head();
				Vector2 CP = P - v3.head();
				bool insideTriangle = false;
				double gamma = ((v2.x - v1.x) * (P.y - v1.y) - (P.x - v1.x) * (v2.y - v1.y)) /
					((v2.x - v1.x) * (v3.y - v1.y) - (v3.x - v1.x) * (v2.y - v1.y));
				double beta = (P.x - v1.x - gamma * (v3.x - v1.x)) / (v2.x - v1.x);
				double alpha = 1.0f - beta - gamma;
				if ((EPSINON < alpha) && (EPSINON < beta) && (EPSINON < gamma)) insideTriangle = true;
				if (!insideTriangle) continue;
				//确认点在某三角形之内了,先假设为上（1）
				if (Seg_Type == 0) Seg_Type = 1;
				double intersection_2_z = alpha * v1.z + beta * v2.z + gamma * v3.z;
				if (intersection_z > intersection_2_z + EPSINON) { //确认为下（>1）
					Seg_Type ++;
					//break;
				}
			}
			if (Seg_Type == 0) {//Top_Seg (Silhouette)
				//drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.9, colorHSV(0.3, 1, 1));
				top.emplace_back(Segment(p1, p2));
				sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
				svg_lines_top += temp;
			}
			else if (Seg_Type == 1) {//Up_Seg
				//drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.6, colorHSV(0, 0, 1));
				up.emplace_back(Segment(p1, p2));
				sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
				svg_lines_up += temp;
			}
			else if (Seg_Type == 2) {//Down_Seg_1 
				//drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.1, colorHSV(0.5, 1, 1));
				down.emplace_back(Segment(p1, p2));
				sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
				svg_lines_down1 += temp;
			}
			else if (Seg_Type == 3) {//Down_Seg_2
				//drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.1, colorHSV(0.5, 1, 1));
				down.emplace_back(Segment(p1, p2));
				sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
				svg_lines_down2 += temp;
			}
			else if (Seg_Type == 4) {//Down_Seg_3 
				//drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.1, colorHSV(0.5, 1, 1));
				down.emplace_back(Segment(p1, p2));
				sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
				svg_lines_down3 += temp;
			}
			else if (Seg_Type == 5) {//Down_Seg_4 
				//drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.1, colorHSV(0.5, 1, 1));
				down.emplace_back(Segment(p1, p2));
				sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
				svg_lines_down4 += temp;
			}
			else if (Seg_Type == 6) {//Down_Seg_5 
				//drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.1, colorHSV(0.5, 1, 1));
				down.emplace_back(Segment(p1, p2));
				sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
				svg_lines_down5 += temp;
			}
			else if (Seg_Type == 7) {//Down_Seg_6 
				//drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.1, colorHSV(0.5, 1, 1));
				down.emplace_back(Segment(p1, p2));
				sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
				svg_lines_down6 += temp;
			}
			else if (Seg_Type == 8) {//Down_Seg_7 
				//drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.1, colorHSV(0.5, 1, 1));
				down.emplace_back(Segment(p1, p2));
				sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
				svg_lines_down7 += temp;
			}
			else {//Down_Seg 8 or deeper
				//drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.1, colorHSV(0.5, 1, 1));
				down.emplace_back(Segment(p1, p2));
				sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
				svg_lines_down8 += temp;
			}
		}
		//if (e % 1000 == 0) this->buff->pushSprite(0, 0);
	}
	//std::cout << "/\n";
	//int time_end = millis();
	//float time = (time_end - time_begin) / 1000.0;
	//std::cout << "Render time thread: " << std::to_string((time_end - time_begin) / 1000.0) << "s\n";

	return 0L;
}





#ifdef _WIN32
std::string svg_lines_top = "";
std::string svg_lines_up = "";
std::string svg_lines_down1 = "";
std::string svg_lines_down2 = "";
std::string svg_lines_down3 = "";
std::string svg_lines_down4 = "";
std::string svg_lines_down5 = "";
std::string svg_lines_down6 = "";
std::string svg_lines_down7 = "";
std::string svg_lines_down8 = "";
uint64_t time_begin = 0;
uint64_t time_end = 0;
#else
String svg_lines_top = "";
String svg_lines_up = "";
String svg_lines_down = "";
#endif
float CreaseAngle = 25;
float cosCrease;

class E512W3DWindow {
public:
#ifdef Epaper_Display
	M5EPD_Canvas* buff;
	TFT_eSprite* zbuff;
#else
	TFT_eSprite* buff;
	TFT_eSprite* zbuff;
	// TFT_eSprite* zbuff_show;
#endif
	uint16_t screen_width, screen_height;

	int16_t sx = 0;
	int16_t sy = 0;
	uint16_t width, height;
	uint16_t bgcolor = 0;
	bool isortho = false;
	float ortho_size = 0.01f;
	float ambient = 0;// 0f - 1f
	float light_strength = 1.0f;

	E512W3DWindow() {
		this->init(0, 0, 160, 80, 0, Vector3(0, -1, 0));
	}

	E512W3DWindow(uint16_t bgcolor) {
		this->init(0, 0, 160, 80, bgcolor, Vector3(0, -1, 0));
	}

	E512W3DWindow(int16_t sx, int16_t sy, uint16_t width, uint16_t height) {
		this->init(sx, sy, width, height, 0, Vector3(0, -1, 0));
	}

	E512W3DWindow(int16_t sx, int16_t sy, uint16_t width, uint16_t height, uint16_t bgcolor) {
		this->init(sx, sy, width, height, bgcolor, Vector3(0, -1, 0));
	}

	E512W3DWindow(int16_t sx, int16_t sy, uint16_t width, uint16_t height, uint16_t bgcolor, Vector3 light) {
		this->init(sx, sy, width, height, bgcolor, light);
	}

	void init(int16_t sx, int16_t sy, uint16_t width, uint16_t height, uint16_t bgcolor, Vector3 light) {
		this->sx = sx;
		this->sy = sy;
		this->width = width;
		this->height = height;
		this->bgcolor = bgcolor;
		this->setDirectionalLight(light);
	}

	~E512W3DWindow() {}

	void resize(uint16_t width, uint16_t height) {
		this->width = width;
		this->height = height;
	}

	void draw() {
		this->dsy = max(this->sy, (int16_t)0);
		this->dsx = max(this->sx, (int16_t)0);
		this->dey = min((int16_t)(this->sy + this->height), (int16_t)(this->screen_height));
		this->dex = min((int16_t)(this->sx + this->width), (int16_t)(this->screen_width));
		if (this->dsy == this->dey || this->dsx == this->dex) { return; }

		this->clear();

		this->updateViewMatrix();
		this->updateLightVector();
		if (this->isortho) {
			this->projescreen = Matrix4x4::orthoscreenMatrix(this->width, this->height, this->ortho_size);
		}
		else {
			this->projescreen = Matrix4x4::projscreenMatrix(this->width, this->height);
		}
		this->drawChild(this->child, Matrix4x4::identity());
	}

	void setDirectionalLight(float x, float y, float z) { this->setDirectionalLight(Vector3(x, y, z)); }

	void setDirectionalLight(Vector3 d) { this->light = Vector3::normalize(Vector3() - d); }

	void addChild(Object3D& o) {
		o.parent = NULL;
		this->child.emplace_back(&o);
	}

	void setCamera(Object3D& o) { this->camera = &o; }

private:
	Object3D* camera = NULL;
	E512Array<Object3D*> child;
	Vector3 light;
	Vector3 light_vector;
	Matrix4x4 view;
	Matrix4x4 projescreen;
	int16_t dsy, dsx, dey, dex;  //绘图真正的起始点及结束点

	void drawChild(E512Array<Object3D*>& child, Matrix4x4 pmat) {
		for (auto&& c : child) {
			if (c->render_type == RenderType::Hide) { continue; }

			Matrix4x4 mat = this->worldMatrix(c, pmat);
			if (c->mesh != NULL) {
				E512Array<Vector3> v = c->mesh->vertexs;
				if (c->render_type == RenderType::WireFrame) {
					this->worldviewTransform(c, mat, v);
					this->projscreenTransform(c, v);
					this->drawWire(c, v);
				}
				if (c->render_type == RenderType::PolygonColor) {
					E512Array<uint16_t> colors(c->mesh->faces.size());
					this->worldviewTransform(c, mat, v);
					this->polygon(c, v, colors);
					this->projscreenTransform(c, v);
					this->drawPolygon(c, v, colors);
				}
				if (c->render_type == RenderType::PolygonNormal) {
					E512Array<uint16_t> colors(c->mesh->faces.size());
					this->worldviewTransform(c, mat, v);
					this->polygonNormal(c, v, colors);
					this->projscreenTransform(c, v);
					this->drawPolygon(c, v, colors);
				}
				if (c->render_type == RenderType::PolygonTexture) {
					E512Array<float> lights(c->mesh->faces.size());
					this->worldviewTransform(c, mat, v);
					this->polygonTexture(c, v, lights);
					this->projscreenTransform(c, v);
					this->drawPolygonTexture(c, v, lights);
				}
				if (c->render_type == RenderType::PolygonTextureDoubleFace) {
					E512Array<float> lights(c->mesh->faces.size());
					this->worldviewTransform(c, mat, v);
					this->polygonTexture(c, v, lights);
					this->projscreenTransform(c, v);
					this->drawPolygonTextureDoubleFace(c, v, lights);
				}
				if (c->render_type == RenderType::Vertex) {
					this->worldviewTransform(c, mat, v);
					this->projscreenTransform(c, v);
					this->drawVertex(c, v);
				}
				if (c->render_type == RenderType::VertexZ) {
					this->worldviewTransform(c, mat, v);
					this->projscreenTransform(c, v);
					this->drawVertexZ(c, v);
				}
				if (c->render_type == RenderType::Edges) {
					E512Array<Vector3> norms(c->mesh->faces.size());
					this->worldviewTransform(c, mat, v);
					this->polygonNormal(c, v, norms);
					this->detectEdge1(c, v, norms);
					this->projscreenTransform(c, v);
					this->polygonNormal(c, v, norms);
					this->detectEdge2(c, v, norms);
					this->drawEdge(c, v, norms, 0.6);
					//                    this->drawPolygonEdge(c, v);
				}
				if (c->render_type == RenderType::EdgesZ) {
					E512Array<Vector3> norms(c->mesh->faces.size());
					E512Array<uint16_t> colors(c->mesh->faces.size());
					this->worldviewTransform(c, mat, v);
					this->polygonNormal(c, v, norms);
					this->detectEdge1(c, v, norms);
					this->projscreenTransform(c, v);
					this->polygonNormal(c, v, norms);
					this->detectEdge2(c, v, norms);
					// this->drawEdge(c, v, norms);
					// this->drawWire(c, v);
					//    this->drawPolygonEdge1(c, v);
//                    for(int h =7;h<960;h+=15)
//                        drawBuffLine(h, 0, h, 540, 1,color565(200,200,200));
//                    for(int d =7;d<540;d+=15)
//                        drawBuffLine(0, d, 960, d, 1,color565(200,200,200));
//                    this->drawPolygonInt(c, v, colors);
//                    this->drawPolygonEdge2(c, v, true);
					// this->drawPolygonEdge(c, v);
					//this->drawEdge(c, v, norms);//检测生成矢量化线段
					this->drawEdge(c, v, 16);//检测生成矢量化线段（多线程）
				}
				if (c->render_type == RenderType::Zbuff) {
					E512Array<uint16_t> colors(c->mesh->faces.size());
					E512Array<Vector3> norms(c->mesh->faces.size());
					this->worldviewTransform(c, mat, v);
					this->polygonNormal(c, v, colors);
					//                    this->polygon(c, v, colors);
					this->polygonNormal(c, v, norms);
					this->detectEdge1(c, v, norms);
					this->projscreenTransform(c, v);
					this->polygonNormal(c, v, norms);
					//                    this->detectEdge2(c, v, norms);
					this->drawPolygonInt(c, v, colors);
					//                    this->drawPolygon(c, v, colors);
					//                    this->drawEdge(c, v, norms, 0.6);
					this->drawZbuffer(0);
					//                    this->drawPolygonEdge2(c, v, true);
					this->drawEdge(c, v, norms, 0.6);
				}
				if (c->render_type == RenderType::Test) {
					E512Array<uint16_t> colors(c->mesh->faces.size());
					E512Array<Vector3> norms(c->mesh->faces.size());
					this->worldviewTransform(c, mat, v);
					// this->polygonNormal(c, v, colors);
//                    this->polygon(c, v, colors);
					this->polygonNormal(c, v, norms);
					this->detectEdge1(c, v, norms);
					this->projscreenTransform(c, v);
					this->polygonNormal(c, v, norms);
					this->detectEdge2(c, v, norms);
					//                    this->drawEdge2(c, v, norms,0.6);
					//                    this->drawPolygonZ(c, v);
					//                    this->drawWire(c, v);
										// this->drawPolygonEdge1(c, v);

					this->drawPolygonInt(c, v, colors);
					//                    this->drawPolygonEdge2(c, v, true);
					//                    this->drawZbuffer(1);
					this->drawPolygonEdge2(c, v, false);
					//                    this->drawPolygon(c, v, colors);
					//                    this->drawWire(c, v);

					//                    //2D测试
					//                    this->buff->fillSprite(color565(255, 255, 255));
					//                    int limit_r = min(this->width/2, this->height/2);
					////                    for(float deg =0.15;deg<(2*3.14); deg+=0.3){
					////                        drawBuffLineSDF(200 + 100*cos(deg), 200 + 100*sin(deg), 200 + 170*cos(deg), 200 + 170*sin(deg), 0.5+0*deg/5, color565(255,0,0));
					//////                        drawBuffLine(200 + 100*cos(deg), 200 + 100*sin(deg), 200 + 170*cos(deg), 200 + 170*sin(deg), color565(255,0,0));
					////                    }
					//
					//                    for (float deg = 0.0; deg < (2 * 3.1415926); deg += 0.1) {
					//                        drawBuffLineSDF(limit_r + 0.1 * cos(deg),
					//                                        limit_r + 0.1 * sin(deg),
					//                                        limit_r + 0.95 * limit_r * cos(deg),
					//                                        limit_r + 0.95 * limit_r * sin(deg),
					//                                        0.5, colorHSV(deg / (2 * 3.1415926), 1, 1));
					////                        drawBuffLine(200 + 100*cos(deg), 200 + 100*sin(deg), 200 + 170*cos(deg), 200 + 170*sin(deg), color565(255,0,0));
					//                    }
					//                    for(float deg =0;deg<(2*3.14); deg+=0.3){
					//                        drawBuffLineSDF2(200 + 100*cos(deg), 200 + 100*sin(deg), 200 + 170*cos(deg), 200 + 170*sin(deg), 0.5+0*deg/5, color565(0,0,255));
					////                        drawBuffLine(200 + 100*cos(deg), 200 + 100*sin(deg), 200 + 170*cos(deg), 200 + 170*sin(deg), color565(255,0,0));
					//                    }
					//                    drawBuffLineSDF(5,5,390,300,1);
					//                    drawBuffLineSDF(5,5,390,250,0.5);
				}
			}
			this->drawChild(c->child, mat);
		}
	}

	void polygonTexture(Object3D* o, E512Array<Vector3>& v, E512Array<float>& lights) {
		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			const Face& f = o->mesh->faces[i];
			const Vector3& v0 = v[f.a];
			const Vector3& v1 = v[f.b];
			const Vector3& v2 = v[f.c];
			const Vector3 n = Vector3::normalize(Vector3::cross(v1 - v0, v2 - v0));
			lights[i] = max(max(Vector3::dot(this->light_vector, n) * this->light_strength, this->ambient), 0.0f);
		}
	}

	void polygon(Object3D* o, E512Array<Vector3>& v, E512Array<uint16_t>& colors) {
		float r = (o->color >> 11) << 3;
		float g = ((o->color >> 5) & 0b111111) << 2;
		float b = (o->color & 0b11111) << 3;

		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			const Face& f = o->mesh->faces[i];
			const Vector3& v0 = v[f.a];
			const Vector3& v1 = v[f.b];
			const Vector3& v2 = v[f.c];
			const Vector3 n = Vector3::normalize(Vector3::cross(v1 - v0, v2 - v0));
			const float d = max(max(Vector3::dot(this->light_vector, n) * this->light_strength, this->ambient), 0.0f);
			colors[i] = color565(min(r * d, 255.0f), min(g * d, 255.0f), min(b * d, 255.0f));
		}
	}

	void polygonNormal(Object3D* o, E512Array<Vector3>& v, E512Array<uint16_t>& colors) {
		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			const Face& f = o->mesh->faces[i];
			const Vector3& v0 = v[f.a];
			const Vector3& v1 = v[f.b];
			const Vector3& v2 = v[f.c];
			const Vector3 n = (Vector3::normalize(Vector3::cross(v1 - v0, v2 - v0)) * 0.5f + 0.5f) * 255.0f; //0
			// const Vector3 n = (Vector3::normalize(Vector3::cross(v1-v0, v2-v1)) * 0.5f + 0.5f) * 255.0f; //1
			// const Vector3 n = (Vector3::normalize(Vector3::cross(v2-v0, v1-v0)) * 0.5f + 0.5f) * 255.0f; //2
			colors[i] = color565(n.x, n.y, n.z);
		}
	}

	void polygonNormal(Object3D* o, E512Array<Vector3>& v, E512Array<Vector3>& norms) { //根据当前顶点数据计算各面的法线
		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			const Face& f = o->mesh->faces[i];
			const Vector3& v0 = v[f.a];
			const Vector3& v1 = v[f.b];
			const Vector3& v2 = v[f.c];
			norms[i] = (Vector3::normalize(Vector3::cross(v1 - v0, v2 - v1)));
		}
	}

	void projscreenTransform(Object3D* o, E512Array<Vector3>& v) {
		for (int i = 0; i < v.size(); ++i) {
			v[i] = Matrix4x4::mul(v[i], this->projescreen);
		}
	}

	Matrix4x4 worldMatrix(Object3D* o, Matrix4x4 pmat) {
		Matrix4x4 mat = Matrix4x4::identity();
		mat = Matrix4x4::mul(mat, Matrix4x4::scaleMatrix(o->scale));
		mat = Matrix4x4::mul(mat, Matrix4x4::rotMatrix(o->rotation));
		mat = Matrix4x4::mul(mat, Matrix4x4::moveMatrix(o->position));
		mat = Matrix4x4::mul(mat, pmat);
		return mat;
	}

	void updateViewMatrix() {
		Matrix4x4 mat = Matrix4x4::identity();

		if (this->camera != NULL) {
			Object3D* obj = this->camera;
			while (obj != NULL) {
				mat = Matrix4x4::mul(Matrix4x4::rotMatrix(Vector3() - obj->rotation), mat);
				mat = Matrix4x4::mul(Matrix4x4::moveMatrix(Vector3() - obj->position), mat);
				obj = obj->parent;
			}
		}

		this->view = mat;
	}

	void updateLightVector() {
		Matrix4x4 mat = Matrix4x4::identity();

		if (this->camera != NULL) {
			Object3D* obj = this->camera;
			while (obj != NULL) {
				mat = Matrix4x4::mul(Matrix4x4::rotMatrix(Vector3() - obj->rotation), mat);
				obj = obj->parent;
			}
		}
		this->light_vector = Matrix4x4::mul(this->light, mat);
	}

	void worldviewTransform(Object3D* o, Matrix4x4 mat, E512Array<Vector3>& v) {
		mat = Matrix4x4::mul(mat, this->view);
		for (int i = 0; i < v.size(); ++i) {
			v[i] = Matrix4x4::mul(v[i], mat);
		}
	}

	void clear() {
		for (int y = this->dsy; y < this->dey; ++y) {
			for (int x = this->dsx; x < this->dex; ++x) {
				this->buff->drawPixel(x, y, this->bgcolor);
				this->zbuff->drawPixel(x, y, 0);
				// this->zbuff_show->drawPixel(x, y, this->bgcolor);
				// this->buff[y*this->width+x] = this->bgcolor;
				// this->zbuff[y*this->width+x] = 0;
			}
		}
	}

	void drawWire(Object3D* o, E512Array<Vector3>& v) {
		//        svg_lines_up = "";
		//        char temp[100];
		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			const Face& f = o->mesh->faces[i];
			const Vector3& v1 = v[f.a];
			const Vector3& v2 = v[f.b];
			const Vector3& v3 = v[f.c];
			//            if (Vector3::cross(v2 - v1, v3 - v2).z > 0) { continue; }//背面剔除
			if (!((v1.z > 0 && v1.z < 1) || (v2.z > 0 && v2.z < 1) || (v3.z > 0 && v3.z < 1))) { continue; }
			if (!((v1.x >= 0 && v1.x < this->width) || (v2.x >= 0 && v2.x < this->width) ||
				(v3.x >= 0 && v3.x < this->width))) {
				continue;
			}
			if (!((v1.y >= 0 && v1.y < this->height) || (v2.y >= 0 && v2.y < this->height) ||
				(v3.y >= 0 && v3.y < this->height))) {
				continue;
			}
			this->drawBuffLine(v1.x, v1.y, v2.x, v2.y, o->color);
			this->drawBuffLine(v2.x, v2.y, v3.x, v3.y, o->color);
			this->drawBuffLine(v3.x, v3.y, v1.x, v1.y, o->color);
			//            sprintf(temp, "<line x1=\"%.1f\" y1=\"%.1f\" x2=\"%.1f\" y2=\"%.1f\"/>\n", v1.x, v1.y, v2.x, v2.y);
			//            svg_lines_up += temp;
			//            sprintf(temp, "<line x1=\"%.1f\" y1=\"%.1f\" x2=\"%.1f\" y2=\"%.1f\"/>\n", v3.x, v3.y, v2.x, v2.y);
			//            svg_lines_up += temp;
			//            sprintf(temp, "<line x1=\"%.1f\" y1=\"%.1f\" x2=\"%.1f\" y2=\"%.1f\"/>\n", v1.x, v1.y, v3.x, v3.y);
			//            svg_lines_up += temp;
		}
	}

	// void drawEdgeAll (Object3D* o, E512Array<Vector3>& v) {
	//     uint32_t size = o->mesh->edges.size();
	//     for (int i = 0; i < size; ++i) {
	//         const Edge e = o->mesh->edges[i];
	//         const Vector3& v1 = v[e.va];
	//         const Vector3& v2 = v[e.vb];
	//         this->drawBuffLine(v1.x, v1.y, v2.x, v2.y, colorHSV((float)i/(float)size,1.0,1.0));
	//                     // this->drawBuffLine(v1.x, v1.y, v2.x, v2.y, colorHSV(map(i,0,size,0,1.0),1.0,1.0));
	//     }
	// }

	void detectEdge1(Object3D* o, E512Array<Vector3>& v, E512Array<Vector3>& norms) { //检测固有边线：crease及border
		uint32_t size = o->mesh->edges.size();
		for (int i = 0; i < size; i++) {
			float cos = Vector3::dot(norms[o->mesh->edges[i].fa], norms[o->mesh->edges[i].fb]);
			if (o->mesh->edges[i].n == 1) o->mesh->edges[i].edge_type = EdgeType::Border;
			else if (cos < cosCrease && cos > -1.f * cosCrease) {
				o->mesh->edges[i].edge_type = EdgeType::Crease;
			}
			else {
				o->mesh->edges[i].edge_type = EdgeType::Normal;
				continue;
			}
		}
	}

	void detectEdge2(Object3D* o, E512Array<Vector3>& v, E512Array<Vector3>& norms) { //检测轮廓边线：contour
		uint32_t size = o->mesh->edges.size();
		for (int i = 0; i < size; i++) {
			if (o->mesh->edges[i].edge_type == EdgeType::Normal)
				if (norms[o->mesh->edges[i].fa].z * norms[o->mesh->edges[i].fb].z < 0)
					o->mesh->edges[i].edge_type = EdgeType::Contour;
		}
	}
#define MAX_THREAD 20
	void drawEdge(Object3D* o, E512Array<Vector3>& v, int thread_num) { //检测生成矢量化线段(多线程)
		time_begin = millis();
		svg_lines_top = "";
		svg_lines_up = "";
		svg_lines_down1 = "";
		svg_lines_down2 = "";
		svg_lines_down3 = "";
		svg_lines_down4 = "";
		svg_lines_down5 = "";
		svg_lines_down6 = "";
		svg_lines_down7 = "";
		svg_lines_down8 = "";
		param param[MAX_THREAD];
		HANDLE handel[MAX_THREAD];
		std::string lines_top[MAX_THREAD];
		std::string lines_up[MAX_THREAD];
		std::string lines_down1[MAX_THREAD];
		std::string lines_down2[MAX_THREAD];
		std::string lines_down3[MAX_THREAD];
		std::string lines_down4[MAX_THREAD];
		std::string lines_down5[MAX_THREAD];
		std::string lines_down6[MAX_THREAD];
		std::string lines_down7[MAX_THREAD];
		std::string lines_down8[MAX_THREAD];
		E512Array<Segment> top_seg[MAX_THREAD];
		E512Array<Segment> up_seg[MAX_THREAD];
		E512Array<Segment> down_seg[MAX_THREAD];

		for (int i = 0; i < thread_num; i++)
		{
			param[i].thread_num = thread_num;
			param[i].thread_index = i;
			param[i].o = o;
			param[i].v = &v;
			param[i].lines_top = &lines_top[i];
			param[i].lines_up = &lines_up[i];
			param[i].lines_down1 = &lines_down1[i];
			param[i].lines_down2 = &lines_down2[i];
			param[i].lines_down3 = &lines_down3[i];
			param[i].lines_down4 = &lines_down4[i];
			param[i].lines_down5 = &lines_down5[i];
			param[i].lines_down6 = &lines_down6[i];
			param[i].lines_down7 = &lines_down7[i];
			param[i].lines_down8 = &lines_down8[i];
			param[i].top = &top_seg[i];
			param[i].up = &up_seg[i];
			param[i].down = &down_seg[i];
			handel[i] = CreateThread(NULL, 0, DrawEdgeThread, &param[i], 0, NULL);   //创建线程，传入参数

		}
		for (int i = 0; i < thread_num; i++)
		{
			WaitForSingleObject(handel[i], INFINITE);   //等待线程执行结束返回主线程
		}
		for (int i = 0; i < thread_num; i++)//拼合数据
		{
			svg_lines_top += lines_top[i];
			svg_lines_up += lines_up[i];
			svg_lines_down1 += lines_down1[i];
			svg_lines_down2 += lines_down2[i];
			svg_lines_down3 += lines_down3[i];
			svg_lines_down4 += lines_down4[i];
			svg_lines_down5 += lines_down5[i];
		}
		for (int i = 0; i < thread_num; i++)
		{
			for (int j = 0; j < down_seg[i].size(); j++)
			{
				Vector2& p1 = down_seg[i][j].a;
				Vector2& p2 = down_seg[i][j].b;
				drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.1, colorHSV(0.5, 1, 1));
			}
		}
		for (int i = 0; i < thread_num; i++)
		{
			for (int j = 0; j < up_seg[i].size(); j++)
			{
				Vector2& p1 = up_seg[i][j].a;
				Vector2& p2 = up_seg[i][j].b;
				drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.6, colorHSV(0, 0, 1));
			}
		}
		for (int i = 0; i < thread_num; i++)
		{
			for (int j = 0; j < top_seg[i].size(); j++)
			{
				Vector2& p1 = top_seg[i][j].a;
				Vector2& p2 = top_seg[i][j].b;
				drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.9, colorHSV(0.3, 1, 1));
			}
		}


		time_end = millis();
		float time = (time_end - time_begin) / 1000.0;
		std::cout << "Render time: " << std::to_string((time_end - time_begin) / 1000.0) << "s\n";
	}





	void drawEdge(Object3D* o, E512Array<Vector3>& v, E512Array<Vector3>& norms) { //检测生成矢量化线段
		time_begin = millis();
		svg_lines_top = "";
		svg_lines_up = "";
		svg_lines_down1 = "";
		char temp[100];
		for (uint32_t e = 0; e < o->mesh->edges.size(); e++) {
			if (e % 10000 == 0) std::cout << "|";
			else if (e % 1000 == 0) std::cout << ".";

			if (o->mesh->edges[e].edge_type == EdgeType::Normal) continue;
			Vector3 a = v[o->mesh->edges[e].va];
			Vector3 b = v[o->mesh->edges[e].vb];
			E512Array<Vector2> InterSet; //交点坐标序列
			E512Array<double>  InterZ;//交点z序列
			for (uint32_t e1 = 0; e1 < o->mesh->edges.size(); e1++) {
				if (o->mesh->edges[e1].edge_type == EdgeType::Normal) continue;
				if (e1 == e) continue;
				Vector3 c = v[o->mesh->edges[e1].va];
				Vector3 d = v[o->mesh->edges[e1].vb];
				if (min(a.x, b.x) > max(c.x, d.x) ||
					min(c.x, d.x) > max(a.x, b.x) ||
					min(a.y, b.y) > max(c.y, d.y) ||
					min(c.y, d.y) > max(a.y, b.y)) continue; //未通过快速排斥检验
				double area_abc = (a.x - c.x) * (b.y - c.y) - (a.y - c.y) * (b.x - c.x);
				double area_abd = (a.x - d.x) * (b.y - d.y) - (a.y - d.y) * (b.x - d.x);
				if (area_abc * area_abd >= -EPSINON) continue; //三角形面积判据
				double area_cda = (c.x - a.x) * (d.y - a.y) - (c.y - a.y) * (d.x - a.x);
				double area_cdb = area_cda + area_abc - area_abd;// 三角形cdb 面积可用其他三个三角形的面积求得，这里考虑了各个三角形面积的正负号
				if (area_cda * area_cdb >= -EPSINON) continue;
				//确认有交点
				Vector2 intersection;
				double intersection_z = 0;
				double intersection_1_z = 0;
				double t0 = area_cda / (area_abd - area_abc); //交点在原edge上的参数
				double t1 = -area_abc / (area_abd - area_abc);//交点在待比较edge上的参数
				double dx = t0 * (b.x - a.x);
				double dy = t0 * (b.y - a.y);
				double dz = t0 * (b.z - a.z);
				double dz1 = t1 * (d.z - c.z);
				intersection.x = a.x + dx;
				intersection.y = a.y + dy;
				intersection_z = a.z + dz;
				intersection_1_z = c.z + dz1;
				if (SHOW_INTER)
					drawBuffLineSDF(intersection.x, intersection.y, intersection.x + 0.1, intersection.y + 0.1, 2, color565(255, 255, 255));
				//                this->buff->pushSprite(0, 0);
								//插入并排序该交点
				InterSet.emplace_back(intersection);
				InterZ.emplace_back(intersection_z);
				int i;
				for (i = InterSet.size() - 2; i >= 0; i--) {
					if (InterSet[i].x > intersection.x || ((InterSet[i].x == intersection.x) && (InterSet[i].y > intersection.y))) {
						InterSet[i + 1] = InterSet[i];
						InterZ[i + 1] = InterZ[i];
					}
					else break;
				}
				InterSet[i + 1] = intersection;
				InterZ[i + 1] = intersection_z;
			}
			//判断处理端点a
			Vector2 intersection = a.head();
			double intersection_z = a.z;
			//插入并排序该点a
			InterSet.emplace_back(intersection);
			InterZ.emplace_back(intersection_z);
			int i;
			for (i = InterSet.size() - 2; i >= 0; i--) {
				if (InterSet[i].x > intersection.x || ((InterSet[i].x == intersection.x) && (InterSet[i].y > intersection.y))) {
					InterSet[i + 1] = InterSet[i];
					InterZ[i + 1] = InterZ[i];
				}
				else break;
			}
			InterSet[i + 1] = intersection;
			InterZ[i + 1] = intersection_z;
			//判断处理端点b
			intersection = b.head();
			intersection_z = b.z;
			//插入并排序该点b
			InterSet.emplace_back(intersection);
			InterZ.emplace_back(intersection_z);
			for (i = InterSet.size() - 2; i >= 0; i--) {
				if (InterSet[i].x > intersection.x || ((InterSet[i].x == intersection.x) && (InterSet[i].y > intersection.y))) {
					InterSet[i + 1] = InterSet[i];
					InterZ[i + 1] = InterZ[i];
				}
				else break;
			}
			InterSet[i + 1] = intersection;
			InterZ[i + 1] = intersection_z;

			//至此，该edge已被细分为若干线段（segment)，可根据各线段类型作图了
			for (uint32_t index = 0; (index + 1) < InterSet.size(); index++) {
				Vector2 p1 = InterSet[index];
				Vector2 p2 = InterSet[index + 1];
				intersection_z = (InterZ[index] + InterZ[index + 1]) / 2.0;
				uint8_t Seg_Type = 0;
				intersection.x = (p1.x + p2.x) / 2.0;
				intersection.y = (p1.y + p2.y) / 2.0;
				Seg_Type = 2;//先假设为top（2）

				for (uint32_t fi = 0; fi < o->mesh->faces.size(); fi++) {
					Face& f = o->mesh->faces[fi];
					Vector3& v1 = v[f.a];
					Vector3& v2 = v[f.b];
					Vector3& v3 = v[f.c];
					if (intersection.x < min(v1.x, min(v2.x, v3.x)) ||
						intersection.y < min(v1.y, min(v2.y, v3.y)) ||
						intersection.x > max(v1.x, max(v2.x, v3.x)) ||
						intersection.y > max(v1.y, max(v2.y, v3.y)))
						continue; //点在三角形AABB之外
					Vector2 P = intersection;
					Vector2 AP = P - v1.head();
					Vector2 BP = P - v2.head();
					Vector2 CP = P - v3.head();
					bool insideTriangle = false;
					double gamma = ((v2.x - v1.x) * (P.y - v1.y) - (P.x - v1.x) * (v2.y - v1.y)) /
						((v2.x - v1.x) * (v3.y - v1.y) - (v3.x - v1.x) * (v2.y - v1.y));
					double beta = (P.x - v1.x - gamma * (v3.x - v1.x)) / (v2.x - v1.x);
					double alpha = 1.0f - beta - gamma;
					if ((EPSINON < alpha) && (EPSINON < beta) && (EPSINON < gamma)) insideTriangle = true;
					if (!insideTriangle) continue;
					//确认点在某三角形之内了,先假设为上（1）
					if (Seg_Type == 2) Seg_Type = 1;
					double intersection_2_z = alpha * v1.z + beta * v2.z + gamma * v3.z;
					if (intersection_z > intersection_2_z + EPSINON) { //确认为下（0）
						Seg_Type = 0;
						break;
					}
				}
				if (Seg_Type == 2) {//Top_Seg (Silhouette)
					drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.9, colorHSV(0.3, 1, 1));
					sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
					svg_lines_top += temp;
				}
				else if (Seg_Type == 1) {//Up_Seg
					drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.6, colorHSV(0, 0, 1));
					sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
					svg_lines_up += temp;
				}
				else {//Down_Seg
					drawBuffLineSDF(p1.x, p1.y, p2.x, p2.y, 0.1, colorHSV(0.5, 1, 1));
					sprintf(temp, "<line x1=\"%.3f\" y1=\"%.3f\" x2=\"%.3f\" y2=\"%.3f\"/>\n", p1.x, p1.y, p2.x, p2.y);
					svg_lines_down1 += temp;
				}
			}
#ifdef _WIN32
			if (e % 1000 == 0) this->buff->pushSprite(0, 0);
#endif
		}
#ifdef _WIN32
		std::cout << "/\n";
		time_end = millis();
		float time = (time_end - time_begin) / 1000.0;
		//if(time>30) 
		std::cout << "Render time: " << std::to_string((time_end - time_begin) / 1000.0) << "s\n";
#endif
	}

	void drawEdge(Object3D* o, E512Array<Vector3>& v, E512Array<Vector3>& norms, float r) {
		uint32_t size = o->mesh->edges.size();
		svg_lines_up = "";
		char temp[100];
		for (int i = 0; i < size; i++) {
			Edge e = o->mesh->edges[i];
			if (e.edge_type == EdgeType::Crease)
			{ //
				const Vector3& v1 = v[e.va];
				const Vector3& v2 = v[e.vb];
				// this->drawBuffLine(v1.x, v1.y, v2.x, v2.y, colorHSV((float)i/(float)(size-1),1.0,1.0));
				this->drawBuffLineSDF(v1.x, v1.y, v2.x, v2.y, r, o->color);
				//                this->drawBuffLine(v1.x, v1.y, v2.x, v2.y, colorHSV(0.2, 1, 1));
				sprintf(temp, "<line x1=\"%.1f\" y1=\"%.1f\" x2=\"%.1f\" y2=\"%.1f\"/>\n", v1.x, v1.y, v2.x, v2.y);
				svg_lines_up += temp;
			}
			else if (e.edge_type == EdgeType::Contour)
			{ //
				const Vector3& v1 = v[e.va];
				const Vector3& v2 = v[e.vb];
				// this->drawBuffLine(v1.x, v1.y, v2.x, v2.y, colorHSV((float)i/(float)(size-1),1.0,1.0));
				this->drawBuffLineSDF(v1.x, v1.y, v2.x, v2.y, r, o->color);
				//                this->drawBuffLine(v1.x, v1.y, v2.x, v2.y, colorHSV(0.8, 1, 1));
				// Serial.printf("edge %d: fan(%.2f, %.2f, %.2f), fbn(%.2f, %.2f, %.2f), \tdot=%.2f,\tva=%d \tvb=%d \tfa=%d \tfb=%d \ttype=%d\n",i,norms[e.fa].x,norms[e.fa].y,norms[e.fa].z,norms[e.fb].x,norms[e.fb].y,norms[e.fb].z, cos,e.va,e.vb,e.fa,e.fb,e.edge_type );
				sprintf(temp, "<line x1=\"%.1f\" y1=\"%.1f\" x2=\"%.1f\" y2=\"%.1f\"/>\n", v1.x, v1.y, v2.x, v2.y);
				svg_lines_up += temp;
			}
			else if (e.edge_type == EdgeType::Border)
			{ //
				const Vector3& v1 = v[e.va];
				const Vector3& v2 = v[e.vb];
				// this->drawBuffLine(v1.x, v1.y, v2.x, v2.y, colorHSV((float)i/(float)(size-1),1.0,1.0));
				this->drawBuffLineSDF(v1.x, v1.y, v2.x, v2.y, r, colorHSV(0.2, 1, 1));
				//                this->drawBuffLine(v1.x, v1.y, v2.x, v2.y,/* o->color */colorHSV(0.2, 1, 1));
				// Serial.printf("edge %d: fan(%.2f, %.2f, %.2f), fbn(%.2f, %.2f, %.2f), \tdot=%.2f,\tva=%d \tvb=%d \tfa=%d \tfb=%d \ttype=%d\n",i,norms[e.fa].x,norms[e.fa].y,norms[e.fa].z,norms[e.fb].x,norms[e.fb].y,norms[e.fb].z, cos,e.va,e.vb,e.fa,e.fb,e.edge_type );
				// sprintf(temp, "<line x1=\"%.1f\" y1=\"%.1f\" x2=\"%.1f\" y2=\"%.1f\" stroke=\"rgb(0,0,255)\"/>\n", v1.x, v1.y, v2.x, v2.y);
				sprintf(temp, "<line x1=\"%.1f\" y1=\"%.1f\" x2=\"%.1f\" y2=\"%.1f\"/>\n", v1.x, v1.y, v2.x, v2.y);
				svg_lines_up += temp;
			}
		}
	}

	void drawVertex(Object3D* o, E512Array<Vector3>& v) {
		for (int i = 0; i < v.size(); ++i) {
			if (this->inSide2(v[i].x, v[i].y))
				this->buff->drawPixel(v[i].x + this->sx, v[i].y + this->sy, o->color);
		}
	}

	void drawVertexZ(Object3D* o, E512Array<Vector3>& v) {
		float k = 0;
		for (int i = 0; i < v.size(); ++i) {
			// this->buff->drawPixel(v[i].x+this->sx, v[i].y+this->sy, color565(min(v[i].z*k, 255.0f), min(v[i].z*k, 255.0f),  255.0f));
			k = (v[i].z - 0.4) * 2.5;
			// Serial.println(k);
			// this->buff->drawPixel(v[i].x+this->sx, v[i].y+this->sy, colorHSV(0.5,1.0,(1-max(0.0,min(k,1.0)))));
			if (this->inSide2(v[i].x, v[i].y))
				this->buff->drawPixel(v[i].x + this->sx, v[i].y + this->sy, colorHSV(max(0.0, min(k, 1.0)), 1.0, 1.0));
			// this->buff->fillCircle(v[i].x+this->sx, v[i].y+this->sy, 2, colorHSV(max(0.0,min(k,1.0)),1.0,1.0));
		}
	}

	void drawPolygon(Object3D* o, E512Array<Vector3>& v, E512Array<uint16_t>& colors) {
		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			const Face& f = o->mesh->faces[i];
			const Vector3& v1 = v[f.a];
			const Vector3& v2 = v[f.b];
			const Vector3& v3 = v[f.c];
			if (Vector3::cross(v2 - v1, v3 - v2).z > 0) { continue; } //背面剔除
			if (!((v1.z > 0 && v1.z < 1) || (v2.z > 0 && v2.z < 1) || (v3.z > 0 && v3.z < 1))) { continue; }
			if (!((v1.x >= 0 && v1.x < this->width) || (v2.x >= 0 && v2.x < this->width) ||
				(v3.x >= 0 && v3.x < this->width))) {
				continue;
			}
			if (!((v1.y >= 0 && v1.y < this->height) || (v2.y >= 0 && v2.y < this->height) ||
				(v3.y >= 0 && v3.y < this->height))) {
				continue;
			}
			uint16_t z = (1.0f - (v1.z + v2.z + v3.z) * 0.333f) * 32767.0; //简化：认为每个三角面内各点的深度值相同
			this->fillTriangle(o, v, i, z, colors[i]);
		}
	}

	//使用重心坐标深度插值(Z-Interpolation)的三角形绘制算法
	void drawPolygonInt(Object3D* o, E512Array<Vector3>& v, E512Array<uint16_t>& colors) {
		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			Face& f = o->mesh->faces[i];
			Vector3& v1 = v[f.a];
			Vector3& v2 = v[f.b];
			Vector3& v3 = v[f.c];
			if (Vector3::cross(v2 - v1, v3 - v2).z > 0) { continue; } //背面剔除
			if (!((v1.z > 0 && v1.z < 1) || (v2.z > 0 && v2.z < 1) || (v3.z > 0 && v3.z < 1))) { continue; }
			if (!((v1.x >= 0 && v1.x < this->width) || (v2.x >= 0 && v2.x < this->width) ||
				(v3.x >= 0 && v3.x < this->width))) {
				continue;
			}
			if (!((v1.y >= 0 && v1.y < this->height) || (v2.y >= 0 && v2.y < this->height) ||
				(v3.y >= 0 && v3.y < this->height))) {
				continue;
			}
			Vector2 AB = (v2 - v1).head();
			Vector2 BC = (v3 - v2).head();
			Vector2 CA = (v1 - v3).head();
			// 求包围三角形的最小四边形，这样仅处理四边形即可
			int16_t x_min = floor(min(v1.x, min(v2.x, v3.x)));
			int16_t x_max = ceil(max(v1.x, max(v2.x, v3.x)));
			int16_t y_min = floor(min(v1.y, min(v2.y, v3.y)));
			int16_t y_max = ceil(max(v1.y, max(v2.y, v3.y))); //开始写成了x，调了好久
			x_min = max((int16_t)0, (int16_t)x_min);
			x_max = (int16_t)min(this->width - 2, (int16_t)x_max);
			y_min = max((int16_t)0, (int16_t)y_min);
			y_max = (int16_t)min(this->height - 2, (int16_t)y_max);
			bool MSAA = false;
			if (MSAA) {
				// 格子里的细分四个小点坐标
				const float x_inc[4] = { 0.25, 0.75, 0.25, 0.75 };
				const float y_inc[4] = { 0.25, 0.25, 0.75, 0.75 };

				for (int x = x_min; x <= x_max; x++)
					for (int y = y_min; y <= y_max; y++) {
						uint16_t maxDepth = 0;
						// 四个小点中落入三角形中的点的个数
						int count = 0;
						// 对四个小点坐标进行判断
						for (int j = 0; j < 4; j++) {
							// 判断小点是否在三角形内
							Vector2 P(x + x_inc[j], y + y_inc[j]);
							//                            Vector2 P(x + 0.5, y + 0.5);
							Vector2 AP = P - v1.head();
							Vector2 BP = P - v2.head();
							Vector2 CP = P - v3.head();
							float gamma = ((v2.x - v1.x) * (P.y - v1.y) - (P.x - v1.x) * (v2.y - v1.y)) /
								((v2.x - v1.x) * (v3.y - v1.y) - (v3.x - v1.x) * (v2.y - v1.y));
							float beta = (P.x - v1.x - gamma * (v3.x - v1.x)) / (v2.x - v1.x);
							float alpha = 1.0f - beta - gamma;
							if ((0 <= alpha) && (0 <= beta) && (0 <= gamma)) {
								uint16_t z = (1.0f - (alpha * v1.z + beta * v2.z + gamma * v3.z)) * 32767.0;
								maxDepth = max(maxDepth, z);
								count++;
							}
						}
						if (count != 0) { //至少有一个点落入三角形
							if (maxDepth > this->zbuff->readPixel(x + this->sx, y + this->sy)) {
								//                                uint16_t pcolor = this->zbuff->readPixel(x + this->sx, y + this->sy) * count / 4.0;
								//                                uint16_t pcolor = colors[i] * count / 4.0;
								//                                uint16_t pcolor = colorHSV(0.5,1,0.5*count/4.0);
								//                                uint16_t r = colors[i] >> 11;
								//                                uint16_t g = (colors[i] << 5) >> 11;
								//                                uint16_t b = (colors[i]  & 0x001F) >> 11;

								uint16_t r = (((colors[i] & 0xF800) >> 11) << 3);
								uint16_t g = (((colors[i] & 0x07E0) >> 5) << 2);
								uint16_t b = (((colors[i] & 0x001F)) << 3);
								r = (r * count) / 4.0;
								g = (g * count) / 4.0;
								b = (b * count) / 4.0;
								uint16_t pcolor = color565(r, g, b);
								//如何平滑像素颜色还没确定
								// 替换深度
								this->zbuff->drawPixel(x + this->sx, y + this->sy, maxDepth);
								// 修改颜色
								this->buff->drawPixel(x + this->sx, y + this->sy, pcolor);
								//                            this->buff->drawPixel(x + this->sx, y + this->sy, z_color);//画出深度值
								//                            this->buff->drawPixel(x + this->sx, y + this->sy, 0); //画成黑色
								//                                this->buff->drawPixel(x + this->sx, y + this->sy, this->bgcolor); //画成背景色
							}
						}
					}

			}
			else {
				for (int x = x_min; x <= x_max; x++)
					for (int y = y_min; y <= y_max; y++) {
						// 判断点是否在三角形内
						Vector2 P(x + 0.5, y + 0.5);
						//                    Vector2 P((x_min+x_max)/2.0, (y_min+y_max)/2.0);
						Vector2 AP = P - v1.head();
						Vector2 BP = P - v2.head();
						Vector2 CP = P - v3.head();
						bool insideTriangle = false;
						//                    if ((AB.x * AP.y - AB.y * AP.x < 0) && (BC.x * BP.y - BC.y * BP.x < 0) &&
						//                        (CA.x * CP.y - CA.y * CP.x < 0)) //难道是左手坐标系？
						//                        insideTriangle = true;
						//                     if ((AB.x * AP.y - AB.y * AP.x > 0) && (BC.x * BP.y - BC.y * BP.x > 0) &&
						//                             (CA.x * CP.y - CA.y * CP.x > 0))
						//                        insideTriangle = true;
						float gamma = ((v2.x - v1.x) * (P.y - v1.y) - (P.x - v1.x) * (v2.y - v1.y)) /
							((v2.x - v1.x) * (v3.y - v1.y) - (v3.x - v1.x) * (v2.y - v1.y));
						float beta = (P.x - v1.x - gamma * (v3.x - v1.x)) / (v2.x - v1.x);
						float alpha = 1.0f - beta - gamma;
						if ((0 <= alpha) && (0 <= beta) && (0 <= gamma))
							insideTriangle = true;

						if (insideTriangle) { //如果点在三角形内
							//computeBarycentric2D
//                        float gamma = ((v2.x - v1.x) * (y - v1.y) - (x - v1.x) * (v2.y - v1.y)) /
//                                      ((v2.x - v1.x) * (v3.y - v1.y) - (v3.x - v1.x) * (v2.y - v1.y));
//                        float beta = (x - v1.x - gamma * (v3.x - v1.x)) / (v2.x - v1.x);
//                        float alpha = 1.0f - beta - gamma;
							//仿射插值（在屏幕空间插值），并非透视正确，但较为简单
							uint16_t z = (1.0f - (alpha * v1.z + beta * v2.z + gamma * v3.z)) * 32767.0;
							//                        uint16_t z_color = colorHSV(0.2, 0, (z - 10000.0) / (30000 - 10000.0));
							uint16_t z_color = colorHSV(0.2, 0, z / 32767.0);
							if (z > this->zbuff->readPixel(x + this->sx, y + this->sy)) {
								this->zbuff->drawPixel(x + this->sx, y + this->sy, z);
								//                                this->buff->drawPixel(x + this->sx, y + this->sy, colors[i]);
								//                            this->buff->drawPixel(x + this->sx, y + this->sy, z_color);//画出深度值
								//                            this->buff->drawPixel(x + this->sx, y + this->sy, 0); //画成黑色
								//                                this->buff->drawPixel(x + this->sx, y + this->sy, colorHSV(0.8,1,0.7));
								this->buff->drawPixel(x + this->sx, y + this->sy, this->bgcolor); //画成背景色
								//                            this->buff->drawPixel(x + this->sx, y + this->sy, color565(59+20,114+20,181+20)); //画成背景色
								//                            this->buff->pushSprite(0, 0);
							}
						}
					}
				//            this->buff->pushSprite(0, 0);
				//            delay(200);
			}
		}
	}

	void drawPolygonEdge1(Object3D* o, E512Array<Vector3>& v) {
		// for (int i = 0; i < o->mesh->faces.size(); ++i) {
		//     const Face& f = o->mesh->faces[i];
		//     const Vector3& v1 = v[f.a];
		//     const Vector3& v2 = v[f.b];
		//     const Vector3& v3 = v[f.c];
		//     if (Vector3::cross(v2 - v1, v3 - v2).z > 0) { continue; } //背面剔除
		//     if (!((v1.z > 0 && v1.z < 1) || (v2.z > 0 && v2.z < 1) || (v3.z > 0 && v3.z < 1))) { continue; }
		//     if (!((v1.x >= 0 && v1.x < this->width) || (v2.x >= 0 && v2.x < this->width) || (v3.x >= 0 && v3.x < this->width))) { continue; }
		//     if (!((v1.y >= 0 && v1.y < this->height) || (v2.y >= 0 && v2.y < this->height) || (v3.y >= 0 && v3.y < this->height))) { continue; }
		//     uint16_t z = (1.0f-(v1.z+v2.z+v3.z)*0.333f) * 32767.0;
		//     this->fillTriangle(o, v, i, z, color565(0,0,0));//面填充背景色
		//     // this->fillTriangle(o, v, i, z, colorHSV(0.2,0, (z-10000.0)/(20000-10000.0))/* color565(0,0,0) */);//面填充背景色
		//     Edge e1(f.a, f.b);
		//     Edge e2(f.b, f.c);
		//     Edge e3(f.c, f.a);
		//     for (uint32_t i = 0; i < o->mesh->edges.size(); ++i) {
		//         if((e1.va == o->mesh->edges[i].va)&&(e1.vb == o->mesh->edges[i].vb)) //查找相应的边
		//         {
		//             if(o->mesh->edges[i].edge_type >= 0)
		//                 this->drawBuffLineZ(v[e1.va].x, v[e1.va].y, v[e1.vb].x, v[e1.vb].y, z);
		//         }
		//         else if((e2.va == o->mesh->edges[i].va)&&(e2.vb == o->mesh->edges[i].vb)) //查找相应的边
		//         {
		//             if(o->mesh->edges[i].edge_type >= 0)
		//                 this->drawBuffLineZ(v[e2.va].x, v[e2.va].y, v[e2.vb].x, v[e2.vb].y, z);
		//         }else if((e3.va == o->mesh->edges[i].va)&&(e3.vb == o->mesh->edges[i].vb)) //查找相应的边
		//         {
		//             if(o->mesh->edges[i].edge_type >= 0)
		//                 this->drawBuffLineZ(v[e3.va].x, v[e3.va].y, v[e3.vb].x, v[e3.vb].y, z);
		//         }
		//     }
		// }
	}

	//    void drawPolygonEdge2(Object3D *o, E512Array<Vector3> &v, bool cover) {
	//        for (int i = 0; i < o->mesh->faces.size(); ++i) {
	//            const Face &f = o->mesh->faces[i];
	//            const Vector3 &v1 = v[f.a];
	//            const Vector3 &v2 = v[f.b];
	//            const Vector3 &v3 = v[f.c];
	//            if (cover) if (Vector3::cross(v2 - v1, v3 - v2).z > 0) { continue; } //背面剔除
	//            if (!((v1.z > 0 && v1.z < 1) || (v2.z > 0 && v2.z < 1) || (v3.z > 0 && v3.z < 1))) { continue; }
	//            if (!((v1.x >= 0 && v1.x < this->width) || (v2.x >= 0 && v2.x < this->width) ||
	//                  (v3.x >= 0 && v3.x < this->width))) { continue; }
	//            if (!((v1.y >= 0 && v1.y < this->height) || (v2.y >= 0 && v2.y < this->height) ||
	//                  (v3.y >= 0 && v3.y < this->height))) { continue; }
	////            uint16_t z = (1.0f-(v1.z+v2.z+v3.z)*0.333f) * 32767.0;
	//            Edge e1(f.a, f.b);
	//            Edge e2(f.b, f.c);
	//            Edge e3(f.c, f.a);
	//            for (uint32_t i = 0; i < o->mesh->edges.size(); ++i) {
	//                if ((e1.va == o->mesh->edges[i].va) && (e1.vb == o->mesh->edges[i].vb)) //查找相应的边
	//                {
	//                    if (o->mesh->edges[i].edge_type > 0)
	////                        this->drawBuffLineSDF(v[e1.va].x, v[e1.va].y, v[e1.vb].x, v[e1.vb].y, v[e1.va].z, v[e1.vb].z,
	////                                              colorHSV(0.2, 0, 1), cover, 0.6);
	//                        this->drawBuffLine(v[e1.va].x, v[e1.va].y, v[e1.vb].x, v[e1.vb].y, v[e1.va].z, v[e1.vb].z,
	//                                           colorHSV(0.2, 0, 1), cover);
	////                    else this->drawBuffLine(v[e1.va].x, v[e1.va].y, v[e1.vb].x, v[e1.vb].y, v[e1.va].z, v[e1.vb].z, colorHSV(0.7,1,1));
	//                } else if ((e2.va == o->mesh->edges[i].va) && (e2.vb == o->mesh->edges[i].vb)) //查找相应的边
	//                {
	//                    if (o->mesh->edges[i].edge_type > 0)
	////                        this->drawBuffLineSDF(v[e2.va].x, v[e2.va].y, v[e2.vb].x, v[e2.vb].y, v[e2.va].z, v[e2.vb].z,
	////                                              colorHSV(0.2, 0, 1), cover, 0.6);
	//                        this->drawBuffLine(v[e2.va].x, v[e2.va].y, v[e2.vb].x, v[e2.vb].y, v[e2.va].z, v[e2.vb].z,
	//                                           colorHSV(0.2, 0, 1), cover);
	////                    else this->drawBuffLine(v[e2.va].x, v[e2.va].y, v[e2.vb].x, v[e2.vb].y, v[e2.va].z, v[e2.vb].z, colorHSV(0.7,1,1));
	//                } else if ((e3.va == o->mesh->edges[i].va) && (e3.vb == o->mesh->edges[i].vb)) //查找相应的边
	//                {
	//                    if (o->mesh->edges[i].edge_type > 0)
	////                        this->drawBuffLineSDF(v[e3.va].x, v[e3.va].y, v[e3.vb].x, v[e3.vb].y, v[e3.va].z, v[e3.vb].z,
	////                                              colorHSV(0.2, 0, 1), cover, 0.6);
	//                        this->drawBuffLine(v[e3.va].x, v[e3.va].y, v[e3.vb].x, v[e3.vb].y, v[e3.va].z, v[e3.vb].z,
	//                                           colorHSV(0.2, 0, 1), cover);
	////                    else this->drawBuffLine(v[e3.va].x, v[e3.va].y, v[e3.vb].x, v[e3.vb].y, v[e3.va].z, v[e3.vb].z, colorHSV(0.7,1,1));
	//                }
	//            }
	//        }
	//    }
	void drawPolygonEdge2(Object3D* o, E512Array<Vector3>& v, bool cover) {
		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			const Face& f = o->mesh->faces[i];
			const Vector3& v1 = v[f.a];
			const Vector3& v2 = v[f.b];
			const Vector3& v3 = v[f.c];
			if (cover) if (Vector3::cross(v2 - v1, v3 - v2).z > 0) { continue; } //背面剔除
			if (!((v1.z > 0 && v1.z < 1) || (v2.z > 0 && v2.z < 1) || (v3.z > 0 && v3.z < 1))) { continue; }
			if (!((v1.x >= 0 && v1.x < this->width) || (v2.x >= 0 && v2.x < this->width) ||
				(v3.x >= 0 && v3.x < this->width))) {
				continue;
			}
			if (!((v1.y >= 0 && v1.y < this->height) || (v2.y >= 0 && v2.y < this->height) ||
				(v3.y >= 0 && v3.y < this->height))) {
				continue;
			}
			//            uint16_t z = (1.0f-(v1.z+v2.z+v3.z)*0.333f) * 32767.0;
			Edge e1(f.a, f.b);
			Edge e2(f.b, f.c);
			Edge e3(f.c, f.a);
			for (uint32_t i = 0; i < o->mesh->edges.size(); ++i) {
				if ((e1.va == o->mesh->edges[i].va) && (e1.vb == o->mesh->edges[i].vb)) //查找相应的边
				{
					if (o->mesh->edges[i].edge_type > 0)
						this->drawBuffLineSDF(v[e1.va].x, v[e1.va].y, v[e1.vb].x, v[e1.vb].y, v[e1.va].z, v[e1.vb].z,
							colorHSV(0.2, 0, 1), cover, 0.6);
					//                        this->drawBuffLine(v[e1.va].x, v[e1.va].y, v[e1.vb].x, v[e1.vb].y, v[e1.va].z, v[e1.vb].z,
					//                                           colorHSV(0.2, 0, 1), cover);
					//                    else this->drawBuffLine(v[e1.va].x, v[e1.va].y, v[e1.vb].x, v[e1.vb].y, v[e1.va].z, v[e1.vb].z, colorHSV(0.7,1,1));
				}
				else if ((e2.va == o->mesh->edges[i].va) && (e2.vb == o->mesh->edges[i].vb)) //查找相应的边
				{
					if (o->mesh->edges[i].edge_type > 0)
						this->drawBuffLineSDF(v[e2.va].x, v[e2.va].y, v[e2.vb].x, v[e2.vb].y, v[e2.va].z, v[e2.vb].z,
							colorHSV(0.2, 0, 1), cover, 0.6);
					//                        this->drawBuffLine(v[e2.va].x, v[e2.va].y, v[e2.vb].x, v[e2.vb].y, v[e2.va].z, v[e2.vb].z,
					//                                           colorHSV(0.2, 0, 1), cover);
					//                    else this->drawBuffLine(v[e2.va].x, v[e2.va].y, v[e2.vb].x, v[e2.vb].y, v[e2.va].z, v[e2.vb].z, colorHSV(0.7,1,1));
				}
				else if ((e3.va == o->mesh->edges[i].va) && (e3.vb == o->mesh->edges[i].vb)) //查找相应的边
				{
					if (o->mesh->edges[i].edge_type > 0)
						this->drawBuffLineSDF(v[e3.va].x, v[e3.va].y, v[e3.vb].x, v[e3.vb].y, v[e3.va].z, v[e3.vb].z,
							colorHSV(0.2, 0, 1), cover, 0.6);
					//                        this->drawBuffLine(v[e3.va].x, v[e3.va].y, v[e3.vb].x, v[e3.vb].y, v[e3.va].z, v[e3.vb].z,
					//                                           colorHSV(0.2, 0, 1), cover);
					//                    else this->drawBuffLine(v[e3.va].x, v[e3.va].y, v[e3.vb].x, v[e3.vb].y, v[e3.va].z, v[e3.vb].z, colorHSV(0.7,1,1));
				}
			}
		}
	}

	void drawPolygonEdge(Object3D* o, E512Array<Vector3>& v) {
		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			const Face& f = o->mesh->faces[i];
			const Vector3& v1 = v[f.a];
			const Vector3& v2 = v[f.b];
			const Vector3& v3 = v[f.c];
			if (Vector3::cross(v2 - v1, v3 - v2).z > 0) { continue; } //背面剔除
			if (!((v1.z > 0 && v1.z < 1) || (v2.z > 0 && v2.z < 1) || (v3.z > 0 && v3.z < 1))) { continue; }
			if (!((v1.x >= 0 && v1.x < this->width) || (v2.x >= 0 && v2.x < this->width) ||
				(v3.x >= 0 && v3.x < this->width))) {
				continue;
			}
			if (!((v1.y >= 0 && v1.y < this->height) || (v2.y >= 0 && v2.y < this->height) ||
				(v3.y >= 0 && v3.y < this->height))) {
				continue;
			}
			uint16_t z = (1.0f - (v1.z + v2.z + v3.z) * 0.333f) * 32767.0;
			this->fillTriangle(o, v, i, z, color565(0, 0, 0));//面填充背景色
			//            this->fillTriangle(o, v, i, z, colorHSV(0.2,0, (z-10000.0)/(20000-10000.0))/* color565(0,0,0) */);//面填充背景色
			Edge e1(f.a, f.b);
			Edge e2(f.b, f.c);
			Edge e3(f.c, f.a);
			for (uint32_t i = 0; i < o->mesh->edges.size(); ++i) {
				if ((e1.va == o->mesh->edges[i].va) && (e1.vb == o->mesh->edges[i].vb)) //查找相应的边
				{
					if (o->mesh->edges[i].edge_type > 0)
						this->drawBuffLine(v[e1.va].x, v[e1.va].y, v[e1.vb].x, v[e1.vb].y, z, colorHSV(0.2, 1, 1));
				}
				else if ((e2.va == o->mesh->edges[i].va) && (e2.vb == o->mesh->edges[i].vb)) //查找相应的边
				{
					if (o->mesh->edges[i].edge_type > 0)
						this->drawBuffLine(v[e2.va].x, v[e2.va].y, v[e2.vb].x, v[e2.vb].y, z, colorHSV(0.2, 1, 1));
				}
				else if ((e3.va == o->mesh->edges[i].va) && (e3.vb == o->mesh->edges[i].vb)) //查找相应的边
				{
					if (o->mesh->edges[i].edge_type > 0)
						this->drawBuffLine(v[e3.va].x, v[e3.va].y, v[e3.vb].x, v[e3.vb].y, z, colorHSV(0.2, 1, 1));
				}
			}
		}
	}

	void drawPolygonZ(Object3D* o, E512Array<Vector3>& v) {
		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			const Face& f = o->mesh->faces[i];
			const Vector3& v1 = v[f.a];
			const Vector3& v2 = v[f.b];
			const Vector3& v3 = v[f.c];
			if (Vector3::cross(v2 - v1, v3 - v2).z > 0) { continue; } //背面剔除
			if (!((v1.z > 0 && v1.z < 1) || (v2.z > 0 && v2.z < 1) || (v3.z > 0 && v3.z < 1))) { continue; }
			if (!((v1.x >= 0 && v1.x < this->width) || (v2.x >= 0 && v2.x < this->width) ||
				(v3.x >= 0 && v3.x < this->width))) {
				continue;
			}
			if (!((v1.y >= 0 && v1.y < this->height) || (v2.y >= 0 && v2.y < this->height) ||
				(v3.y >= 0 && v3.y < this->height))) {
				continue;
			}
			uint16_t z = (1.0f - (v1.z + v2.z + v3.z) * 0.333f) * 32767.0;
			this->fillTriangle(o, v, i, z,
				colorHSV(0.2, 0, (z - 10000.0) / (20000 - 10000.0))/* color565(0,0,0) */);//面填充背景色
		}
	}

	void drawPolygonTexture(Object3D* o, E512Array<Vector3>& v, E512Array<float>& lights) {
		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			const Face& f = o->mesh->faces[i];
			const Vector3& v1 = v[f.a];
			const Vector3& v2 = v[f.b];
			const Vector3& v3 = v[f.c];

			if (Vector3::cross(v2 - v1, v3 - v2).z > 0) { continue; }
			if (!((v1.z > 0 && v1.z < 1) || (v2.z > 0 && v2.z < 1) || (v3.z > 0 && v3.z < 1))) { continue; }
			if (!((v1.x >= 0 && v1.x < this->width) || (v2.x >= 0 && v2.x < this->width) ||
				(v3.x >= 0 && v3.x < this->width))) {
				continue;
			}
			if (!((v1.y >= 0 && v1.y < this->height) || (v2.y >= 0 && v2.y < this->height) ||
				(v3.y >= 0 && v3.y < this->height))) {
				continue;
			}
			this->fillTriangleTX(o, v, i, lights[i]);
		}
	}

	void drawPolygonTextureDoubleFace(Object3D* o, E512Array<Vector3>& v, E512Array<float>& lights) {
		for (int i = 0; i < o->mesh->faces.size(); ++i) {
			const Face& f = o->mesh->faces[i];
			const Vector3& v1 = v[f.a];
			const Vector3& v2 = v[f.b];
			const Vector3& v3 = v[f.c];

			if (!((v1.z > 0 && v1.z < 1) || (v2.z > 0 && v2.z < 1) || (v3.z > 0 && v3.z < 1))) { continue; }
			if (!((v1.x >= 0 && v1.x < this->width) || (v2.x >= 0 && v2.x < this->width) ||
				(v3.x >= 0 && v3.x < this->width))) {
				continue;
			}
			if (!((v1.y >= 0 && v1.y < this->height) || (v2.y >= 0 && v2.y < this->height) ||
				(v3.y >= 0 && v3.y < this->height))) {
				continue;
			}
			this->fillTriangleTX(o, v, i, lights[i]);
		}
	}

	void drawZbuffer(uint8_t type) {
		int z_min = 65535;
		int z_max = 0;
		for (int x = 0; x < this->width; x++)
			for (int y = 0; y < this->height; y++) {
				int z_value = this->zbuff->readPixel(x + this->sx, y + this->sy);
				if (z_value == 0) continue;
				z_min = min(z_min, z_value);
				z_max = max(z_max, z_value);
			}
		float z_range = z_max - z_min;
		//        printf("zmin=%d,zmax=%d,zrange=%d\n", z_min, z_max,z_range);

		const float hue_max = 0.75;
		for (int x = 0; x < this->width; x++)
			for (int y = 0; y < this->height; y++) {
				int z_value = this->zbuff->readPixel(x + this->sx, y + this->sy);
				if (z_value == 0) { //背景
					if (type == 0)
						this->buff->drawPixel(x + this->sx, y + this->sy,
							this->bgcolor);
					if (type == 1)
						this->buff->drawPixel(x + this->sx, y + this->sy,
							this->bgcolor);
				}
				else {
					if (type == 0)
						this->buff->drawPixel(x + this->sx, y + this->sy,
							colorHSV(hue_max * (z_max - z_value) / z_range, 1, 1));
					if (type == 1)
						this->buff->drawPixel(x + this->sx, y + this->sy,
							colorHSV(0.8, 0, (float)(z_value - z_min) / z_range));

					//                    this->buff->pushSprite(0, 0);
				}
			}
		for (int x = 0; x < this->width; x++) //draw legend
			for (int y = this->height - 1; y > this->height - 4; y--) {
				if (type == 0)
					this->buff->drawPixel(x + this->sx, y + this->sy,
						colorHSV(hue_max * x / (float)this->width, 1, 1));
				if (type == 1)
					this->buff->drawPixel(x + this->sx, y + this->sy,
						colorHSV(0, 0, 1 - x / (float)this->width));
			}
	}

	inline bool inSide(const int& x, const int& y) {
		return !(x < 0 || x >= this->width || y < 0 || y >= this->height);
	}

	inline bool inSide2(int x, int y) {////
		x += this->sx;
		y += this->sy;
		return !(x < this->dsx || x >= this->dex || y < this->dsy || y >= this->dey);
	}

	inline void swap(int16_t& a, int16_t& b) {
		int16_t c = a;
		a = b;
		b = c;
	}

	inline void swap(float& a, float& b) {
		float c = a;
		a = b;
		b = c;
	}

	inline void swap(double& a, double& b) {
		double c = a;
		a = b;
		b = c;
	}

	inline void
		getUV(float x, float y, float x1, float y1, float x2, float y2, float x3, float y3, float& u, float& v) {
		float t = abs((x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1));
		u = 0;
		v = 0;
		if (t > 0) {
			u = abs((x1 - x) * (y2 - y) - (y1 - y) * (x2 - x)) / t;
			v = abs((x1 - x) * (y3 - y) - (y1 - y) * (x3 - x)) / t;
		}
	}


	/*
	This is the core graphics library for all our displays, providing a common
	set of graphics primitives (points, lines, circles, etc.).  It needs to be
	paired with a hardware-specific library for each display device we carry
	(to handle the lower-level functions).
	Adafruit invests time and resources providing this open source code, please
	support Adafruit & open-source hardware by purchasing products from Adafruit!
	Copyright (c) 2013 Adafruit Industries.  All rights reserved.
	Redistribution and use in source and binary forms, with or without
	modification, are permitted provided that the following conditions are met:
	- Redistributions of source code must retain the above copyright notice,
	  this list of conditions and the following disclaimer.
	- Redistributions in binary form must reproduce the above copyright notice,
	  this list of conditions and the following disclaimer in the documentation
	  and/or other materials provided with the distribution.
	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
	IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
	ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
	LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
	CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
	SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
	INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
	CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
	ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
	POSSIBILITY OF SUCH DAMAGE.
	 */
	 // Adafruit_GFX::drawLine modification: Bresenham's line algorithm
	inline void drawBuffLine(int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint16_t color) {
		if (abs(y2 - y1) > abs(x2 - x1)) {
			this->swap(x1, y1);
			this->swap(x2, y2);
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			// int16_t err = dx / 2;
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			for (; x1 <= x2; ++x1) {
				if (this->inSide2(y1, x1)) {
					this->buff->drawPixel(y1 + this->sx, x1 + this->sy, color);
					// this->zbuff_show->drawPixel(y1+this->sx, x1+this->sy, color);
				}
				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
		}
		else {
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			// int16_t err = dx / 2;
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			for (; x1 <= x2; ++x1) {
				if (this->inSide2(x1, y1)) {
					this->buff->drawPixel(x1 + this->sx, y1 + this->sy, color);
					// this->zbuff_show->drawPixel(x1+this->sx, y1+this->sy, color);
				}
				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
		}
	}

	inline void drawBuffLine(int16_t x1, int16_t y1, int16_t x2, int16_t y2, int16_t z, uint16_t color) {
		// printf("drawing a line:");
		if (abs(y2 - y1) > abs(x2 - x1)) {
			this->swap(x1, y1);
			this->swap(x2, y2);
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			// int16_t err = dx / 2;
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			for (; x1 <= x2; ++x1) {
				if (this->inSide2(y1, x1)) {
					// this->buff->drawPixel(y1 + this->sx, x1 + this->sy, color);
					if (z >= this->zbuff->readPixel(y1 + this->sx, x1 + this->sy) - 2) {
						this->zbuff->drawPixel(y1 + this->sx, x1 + this->sy, z);
						this->buff->drawPixel(y1 + this->sx, x1 + this->sy, color);
						// this->zbuff_show->drawPixel(y1 + this->sx, x1 + this->sy, color);
						// this->zbuff_show->drawPixel(y1 + this->sx, x1 + this->sy, colorHSV(0.5,1,0.6));
						// printf("z=%d\t",z);
					}
					// else  printf("z=%d\t",z);//printf("*");
					else {
						// this->buff->drawPixel(y1 + this->sx, x1 + this->sy, color565(255,255,255));
					}
				}
				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
		}
		else {
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			// int16_t err = dx / 2;
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			for (; x1 <= x2; ++x1) {
				if (this->inSide2(x1, y1)) {
					// this->buff->drawPixel(x1+this->sx, y1+this->sy, color);
					if (z >= this->zbuff->readPixel(x1 + this->sx, y1 + this->sy) - 2) {
						this->zbuff->drawPixel(x1 + this->sx, y1 + this->sy, z);
						this->buff->drawPixel(x1 + this->sx, y1 + this->sy, color);
						// this->zbuff_show->drawPixel(x1 + this->sx, y1 + this->sy, color);
						// this->zbuff_show->drawPixel(x1 + this->sx, y1 + this->sy, colorHSV(0.5,1,0.6));
						// printf("z=%d\t",z);
					}
					// else  printf("z=%d\t",z);//printf("*");
					else {
						// this->buff->drawPixel(x1 + this->sx, y1 + this->sy, color565(255,255,255));
					}
				}

				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
		}
	}

	//带深度插值的任意直线绘制算法
	inline void
		drawBuffLine(int16_t x1, int16_t y1, int16_t x2, int16_t y2, float z1, float z2, uint16_t color, bool cover) {
		const uint16_t bias = 200;
		if (abs(y2 - y1) > abs(x2 - x1)) {
			this->swap(x1, y1);
			this->swap(x2, y2);
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
				this->swap(z1, z2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			// int16_t err = dx / 2;
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			for (; x1 <= x2; ++x1) {
				if (this->inSide2(y1, x1)) {
					float t = (float)(x2 - x1) / (float)dx;
					float zp = z1 * t + z2 * (1 - t);
					uint16_t z = (1.0f - zp) * 32767.0;
					uint16_t z_color = colorHSV(0.2, 0, z / 32767.0);

					if ((z + bias) >= this->zbuff->readPixel(y1 + this->sx, x1 + this->sy)) {
						this->zbuff->drawPixel(y1 + this->sx, x1 + this->sy, z);
						this->buff->drawPixel(y1 + this->sx, x1 + this->sy, color);
						//                        this->buff->drawPixel(y1 + this->sx, x1 + this->sy,
						//                                              colorHSV(0.8, 0, (float) (z - 10274) / 9145.0));
						//                        this->buff->pushSprite(0, 0);
						//                        this->buff->drawPixel(y1 + this->sx, x1 + this->sy, colorHSV(0.5,1,1));
					}
					else if (!cover || ((x1) % 5 < 3))//是否绘制隐藏线。绘制时随机错位。
						//                    this->buff->drawPixel(y1 + this->sx, x1 + this->sy,
						//                                          colorHSV(0.8, 0, (float) (z - 10274) / 9145.0));
						this->buff->drawPixel(y1 + this->sx, x1 + this->sy, colorHSV(0.2, 1, 0.45));
				}
				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
		}
		else {
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
				this->swap(z1, z2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			// int16_t err = dx / 2;
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			for (; x1 <= x2; ++x1) {
				if (this->inSide2(x1, y1)) {
					float t = (float)(x2 - x1) / (float)dx;
					float zp = z1 * t + z2 * (1 - t);
					uint16_t z = (1.0f - zp) * 32767.0;
					uint16_t z_color = colorHSV(0.2, 0, z / 32767.0);
					if ((z + bias) >= this->zbuff->readPixel(x1 + this->sx, y1 + this->sy)) {
						this->zbuff->drawPixel(x1 + this->sx, y1 + this->sy, z);
						this->buff->drawPixel(x1 + this->sx, y1 + this->sy, color);
						//                        this->buff->drawPixel(x1 + this->sx, y1 + this->sy, colorHSV(0.8, 0, (float) (z - 10274) / 9145.0));
						//                        this->buff->pushSprite(0, 0);
						//                        this->buff->drawPixel(x1 + this->sx, y1 + this->sy, colorHSV(0.5,1,1));
					}
					else if (!cover || (((int16_t)x1) % 5 < 3))//是否绘制隐藏线。绘制时随机错位。
						//                    this->buff->drawPixel(x1 + this->sx, y1 + this->sy, colorHSV(0.8, 0, (float) (z - 10274) / 9145.0));
						this->buff->drawPixel(x1 + this->sx, y1 + this->sy, colorHSV(0.2, 1, 0.85));
				}
				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
		}
	}

	inline void drawBuffLineZ(int16_t x1, int16_t y1, int16_t x2, int16_t y2, int16_t z) {
		// printf("drawing a line:");
		if (abs(y2 - y1) > abs(x2 - x1)) {
			this->swap(x1, y1);
			this->swap(x2, y2);
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			// int16_t err = dx / 2;
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			for (; x1 <= x2; ++x1) {
				if (this->inSide2(y1, x1)) {
					// this->buff->drawPixel(y1 + this->sx, x1 + this->sy, color);
					if (z >= this->zbuff->readPixel(y1 + this->sx, x1 + this->sy) - 2) {
						this->zbuff->drawPixel(y1 + this->sx, x1 + this->sy, z);
						// this->buff->drawPixel(y1 + this->sx, x1 + this->sy, color);
						// this->zbuff_show->drawPixel(y1 + this->sx, x1 + this->sy, color);
						// this->zbuff_show->drawPixel(y1 + this->sx, x1 + this->sy, colorHSV(0.5,1,0.6));
						// printf("z=%d\t",z);
					}
					// else  printf("z=%d\t",z);//printf("*");
					else {
						// this->buff->drawPixel(y1 + this->sx, x1 + this->sy, color565(255,255,255));
					}
				}
				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
		}
		else {
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			// int16_t err = dx / 2;
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			for (; x1 <= x2; ++x1) {
				if (this->inSide2(x1, y1)) {
					// this->buff->drawPixel(x1+this->sx, y1+this->sy, color);
					if (z >= this->zbuff->readPixel(x1 + this->sx, y1 + this->sy) - 2) {
						this->zbuff->drawPixel(x1 + this->sx, y1 + this->sy, z);
						// this->buff->drawPixel(x1 + this->sx, y1 + this->sy, color);
						// this->zbuff_show->drawPixel(x1 + this->sx, y1 + this->sy, color);
						// this->zbuff_show->drawPixel(x1 + this->sx, y1 + this->sy, colorHSV(0.5,1,0.6));
						// printf("z=%d\t",z);
					}
					// else  printf("z=%d\t",z);//printf("*");
					else {
						// this->buff->drawPixel(x1 + this->sx, y1 + this->sy, color565(255,255,255));
					}
				}

				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
		}
		// printf("\n");
	}

	// GFXcanvas8::writeFastHLine modification
	inline void drawBuffLineH(int16_t sx, int16_t y, int16_t w, int16_t z, uint16_t color) {
		if (sx >= this->width || y < 0 || y >= this->height) { return; }
		int16_t ex = sx + w - 1;
		if (ex < 0) { return; }
		sx = max(sx, (int16_t)0);
		ex = min(ex, (int16_t)(this->width - 1));

		for (int16_t x = sx; x < ex; ++x) {
			if (!this->inSide2(x, y)) { continue; }
			if (z > this->zbuff->readPixel(x + this->sx, y + this->sy)) {
				this->zbuff->drawPixel(x + this->sx, y + this->sy, z);
				this->buff->drawPixel(x + this->sx, y + this->sy, color);
				// this->zbuff_show->drawPixel(x+this->sx, y+this->sy, color);
				// this->zbuff_show->drawPixel(x+this->sx, y+this->sy, colorHSV(0.5,1,0.6));
				// printf("z=%d\t",z);
			}

		}
	}

	// Adafruit_GFX::fillTriangle modification
	inline void fillTriangle(Object3D* o, E512Array<Vector3>& v, int32_t index, uint16_t z, uint16_t color) {
		const Face& f = o->mesh->faces[index];

		int16_t x1 = v[f.a].x;
		int16_t y1 = v[f.a].y;
		int16_t x2 = v[f.b].x;
		int16_t y2 = v[f.b].y;
		int16_t x3 = v[f.c].x;
		int16_t y3 = v[f.c].y;

		if (y1 > y2) {
			this->swap(y1, y2);
			this->swap(x1, x2);
		}
		if (y2 > y3) {
			this->swap(y3, y2);
			this->swap(x3, x2);
		}
		if (y1 > y2) {
			this->swap(y1, y2);
			this->swap(x1, x2);
		}

		int16_t a, b, y;
		if (y1 == y3) {
			a = b = x1;
			if (x2 < a) {
				a = x2;
			}
			else if (x2 > b) {
				b = x2;
			}
			if (x3 < a) {
				a = x3;
			}
			else if (x3 > b) {
				b = x3;
			}
			this->drawBuffLineH(a, y1, b - a + 1, z, color);
			return;
		}

		int32_t dx21 = x2 - x1;
		int32_t dy21 = y2 - y1;
		int32_t dx31 = x3 - x1;
		int32_t dy31 = y3 - y1;
		int32_t dx32 = x3 - x2;
		int32_t dy32 = y3 - y2;
		int32_t sa = 0;
		int32_t sb = 0;
		int16_t last = y2 == y3 ? y2 : y2 - 1;

		for (y = y1; y <= last; ++y) {
			a = x1 + sa / dy21;
			b = x1 + sb / dy31;
			sa += dx21;
			sb += dx31;
			if (a > b) { this->swap(a, b); }
			this->drawBuffLineH(a, y, b - a + 1, z, color);
		}

		sa = dx32 * (y - y2);
		sb = dx31 * (y - y1);
		for (; y <= y3; ++y) {
			a = x2 + sa / dy32;
			b = x1 + sb / dy31;
			sa += dx32;
			sb += dx31;
			if (a > b) { this->swap(a, b); }
			this->drawBuffLineH(a, y, b - a + 1, z, color);
		}
	}


	// GFXcanvas8::writeFastHLine modification
	inline void drawBuffLineHTX(int16_t sx, int16_t y, int16_t w, int16_t za, int16_t zba, int16_t zca, Object3D* o,
		E512Array<Vector3>& v, int16_t index, float light) {
		if (sx >= this->width || y < 0 || y >= this->height) { return; }
		int16_t ex = sx + w - 1;
		if (ex < 0) { return; }
		sx = max(sx, (int16_t)0);
		ex = min(ex, (int16_t)(this->width - 1));
		const Face& f = o->mesh->faces[index];
		const int16_t v1x = v[f.a].x;
		const int16_t v1y = v[f.a].y;
		const int16_t v2x = v[f.b].x;
		const int16_t v2y = v[f.b].y;
		const int16_t v3x = v[f.c].x;
		const int16_t v3y = v[f.c].y;
		const Face& fuv = o->mesh->uv_faces[index];
		float ax = o->mesh->uv_vertexs[fuv.a].x;
		float ay = o->mesh->uv_vertexs[fuv.a].y;
		float bx = o->mesh->uv_vertexs[fuv.b].x;
		float by = o->mesh->uv_vertexs[fuv.b].y;
		float cx = o->mesh->uv_vertexs[fuv.c].x;
		float cy = o->mesh->uv_vertexs[fuv.c].y;
		float dax = bx - ax;
		float day = by - ay;
		float dbx = cx - ax;
		float dby = cy - ay;
		for (int16_t x = sx; x < ex; ++x) {
			if (!this->inSide2(x, y)) { continue; }
			float u = 0;
			float v = 0;
			this->getUV(x, y, v1x, v1y, v2x, v2y, v3x, v3y, u, v);
			float tu = dax * v + dbx * u + ax;
			float tv = day * v + dby * u + ay;
			uint16_t z = zba * v + zca * u + za;
			if (z > this->zbuff->readPixel(x + this->sx, y + this->sy)) {
				uint16_t color = o->texture->getColor(tu, tv);
				if ((color >> 15) & 1) { continue; }
				float r = ((color >> 10) & 0b11111) << 3;
				float g = ((color >> 5) & 0b11111) << 3;
				float b = (color & 0b11111) << 3;
				color = color565(min(r * light, 255.0f), min(g * light, 255.0f), min(b * light, 255.0f));
				this->zbuff->drawPixel(x + this->sx, y + this->sy, z);
				this->buff->drawPixel(x + this->sx, y + this->sy, color);
			}
		}
	}


	// Adafruit_GFX::fillTriangle modification
	inline void fillTriangleTX(Object3D* o, E512Array<Vector3>& v, int16_t index, float light) {
		const Face& f = o->mesh->faces[index];

		int16_t x1 = v[f.a].x;
		int16_t y1 = v[f.a].y;
		int16_t x2 = v[f.b].x;
		int16_t y2 = v[f.b].y;
		int16_t x3 = v[f.c].x;
		int16_t y3 = v[f.c].y;

		int16_t za = (1.0f - v[f.a].z) * 32767.0;
		int16_t zb = (1.0f - v[f.b].z) * 32767.0;
		int16_t zc = (1.0f - v[f.c].z) * 32767.0;
		int16_t zba = zb - za;
		int16_t zca = zc - za;

		if (y1 > y2) {
			this->swap(y1, y2);
			this->swap(x1, x2);
		}
		if (y2 > y3) {
			this->swap(y3, y2);
			this->swap(x3, x2);
		}
		if (y1 > y2) {
			this->swap(y1, y2);
			this->swap(x1, x2);
		}

		int16_t a, b, y;
		if (y1 == y3) {
			a = b = x1;
			if (x2 < a) {
				a = x2;
			}
			else if (x2 > b) {
				b = x2;
			}
			if (x3 < a) {
				a = x3;
			}
			else if (x3 > b) {
				b = x3;
			}
			this->drawBuffLineHTX(a, y1, b - a + 1, za, zba, zca, o, v, index, light);
			return;
		}

		int32_t dx21 = x2 - x1;
		int32_t dy21 = y2 - y1;
		int32_t dx31 = x3 - x1;
		int32_t dy31 = y3 - y1;
		int32_t dx32 = x3 - x2;
		int32_t dy32 = y3 - y2;
		int32_t sa = 0;
		int32_t sb = 0;
		int16_t last = y2 == y3 ? y2 : y2 - 1;

		for (y = y1; y <= last; ++y) {
			a = x1 + sa / dy21;
			b = x1 + sb / dy31;
			sa += dx21;
			sb += dx31;
			if (a > b) { this->swap(a, b); }
			this->drawBuffLineHTX(a, y, b - a + 1, za, zba, zca, o, v, index, light);
		}

		sa = dx32 * (y - y2);
		sb = dx31 * (y - y1);
		for (; y <= y3; ++y) {
			a = x2 + sa / dy32;
			b = x1 + sb / dy31;
			sa += dx32;
			sb += dx31;
			if (a > b) { this->swap(a, b); }
			this->drawBuffLineHTX(a, y, b - a + 1, za, zba, zca, o, v, index, light);
		}
	}


	float capsuleSDF(float px, float py, float ax, float ay, float bx, float by, float r) {
		float pax = px - ax, pay = py - ay, bax = bx - ax, bay = by - ay;
		float h = fmaxf(fminf((pax * bax + pay * bay) / (bax * bax + bay * bay), 1.0f), 0.0f);
		float dx = pax - bax * h, dy = pay - bay * h;
		return sqrtf(dx * dx + dy * dy) - r;
	}

	//    void alphablend(int16_t x, int16_t y, float alpha, uint16_t color) {
	//        uint16_t color_bg = this->buff->readPixel(x+this->sx, y+this->sy);
	//        uint16_t r = (((color & 0xF800) >> 11) << 3);
	//        uint16_t g = (((color & 0x07E0) >>  5) << 2);
	//        uint16_t b = (((color & 0x001F)      ) << 3);
	//        uint16_t r_bg = (((color_bg & 0xF800) >> 11) << 3);
	//        uint16_t g_bg = (((color_bg & 0x07E0) >>  5) << 2);
	//        uint16_t b_bg = (((color_bg & 0x001F)      ) << 3);
	//        uint16_t color_blend = color565(min(r_bg * (1 - alpha) + r * alpha, 255.0f), min(g_bg * (1 - alpha) + g * alpha, 255.0f), min(b_bg * (1 - alpha) + b * alpha, 255.0f));
	//        this->buff->drawPixel(x+this->sx, y+this->sy, color_blend);
	//    }
#ifdef Epaper_Display
	void alphablend(int16_t x, int16_t y, float alpha, uint8_t color) {
		if (this->inSide2(x, y)) {
			uint8_t color_bg = this->buff->readPixel(x + this->sx, y + this->sy);
			uint8_t color_blend = color_bg * (1 - alpha) + color * alpha;
			this->buff->drawPixel(x + this->sx, y + this->sy, color_blend);
		}
	}
#else
	void alphablend(int16_t x, int16_t y, float alpha, uint16_t color) {
		if (this->inSide2(x, y)) {
			uint16_t color_bg = this->buff->readPixel(x + this->sx, y + this->sy);
			uint16_t r = (((color & 0xF800) >> 11) << 3);
			uint16_t g = (((color & 0x07E0) >> 5) << 2);
			uint16_t b = (((color & 0x001F)) << 3);
			uint16_t r_bg = (((color_bg & 0xF800) >> 11) << 3);
			uint16_t g_bg = (((color_bg & 0x07E0) >> 5) << 2);
			uint16_t b_bg = (((color_bg & 0x001F)) << 3);
			uint16_t color_blend = color565(min(r_bg * (1 - alpha) + r * alpha, 255.0f),
				min(g_bg * (1 - alpha) + g * alpha, 255.0f),
				min(b_bg * (1 - alpha) + b * alpha, 255.0f));
			this->buff->drawPixel(x + this->sx, y + this->sy, color_blend);
		}
	}
#endif

	//    void drawBuffLineSDF(float ax, float ay, float bx, float by, float r, uint16_t color) {
	//        int x0 = (int)floorf(fminf(ax, bx) - r);
	//        int x1 = (int) ceilf(fmaxf(ax, bx) + r);
	//        int y0 = (int)floorf(fminf(ay, by) - r);
	//        int y1 = (int) ceilf(fmaxf(ay, by) + r);
	//        x0 = max((int16_t) 0, (int16_t) x0);
	//        x1 = (int16_t) min(this->width - 2, (int16_t) x1);
	//        y0 = max((int16_t) 0, (int16_t) y0);
	//        y1 = (int16_t) min(this->height - 2, (int16_t) y1);
	//        for (int y = y0; y <= y1; y++)
	//            for (int x = x0; x <= x1; x++)
	//                alphablend(x, y, fmaxf(fminf(0.5f - capsuleSDF(x, y, ax, ay, bx, by, r), 1.0f), 0.0f), color);
	//    }
	void drawBuffLineSDF(float x1p, float y1p, float x2p, float y2p, float r, uint16_t color) { //使用bresenham确定OBB
		int16_t x1 = x1p;
		int16_t y1 = y1p;
		int16_t x2 = x2p;
		int16_t y2 = y2p;
		uint16_t dr = ceil(r) + 1;
		if (abs(y2 - y1) > abs(x2 - x1)) {
			this->swap(x1, y1);
			this->swap(x2, y2);
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			int16_t x_temp = x1;
			int16_t y_temp = y1;
			for (; x1 <= (x2 + dr); ++x1) {
				for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
					//                    this->buff->drawPixel(py+this->sx, x1+this->sy, color565(100,100,255));
					alphablend(py, x1, fmaxf(fminf(0.5f - capsuleSDF(py, x1, x1p, y1p, x2p, y2p, r), 1.0f), 0.0f),
						color);
				}
				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
			y1 = y_temp;
			for (x1 = x_temp; x1 >= (x_temp - dr); x1--) {
				for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
					//                    this->buff->drawPixel(py+this->sx, x1+this->sy, color565(100,100,255));
					alphablend(py, x1, fmaxf(fminf(0.5f - capsuleSDF(py, x1, x1p, y1p, x2p, y2p, r), 1.0f), 0.0f),
						color);
				}// +>--
				err -= dy;
				if (err < 0) {
					y1 -= ystep;
					err += dx;
				}
			}
		}
		else {
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			int16_t x_temp = x1;
			int16_t y_temp = y1;
			for (; x1 <= (x2 + dr); ++x1) {
				for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
					//                    this->buff->drawPixel(x1+this->sx, py+this->sy, color565(100,100,255));
					alphablend(x1, py, fmaxf(fminf(0.5f - capsuleSDF(x1, py, x1p, y1p, x2p, y2p, r), 1.0f), 0.0f),
						color);
				}
				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
			y1 = y_temp;
			for (x1 = x_temp; x1 >= (x_temp - dr); x1--) {
				for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
					//                    this->buff->drawPixel(x1+this->sx, py+this->sy, color565(100,100,255));
					alphablend(x1, py, fmaxf(fminf(0.5f - capsuleSDF(x1, py, x1p, y1p, x2p, y2p, r), 1.0f), 0.0f),
						color);
				}// +>--
				err -= dy;
				if (err < 0) {
					y1 -= ystep;
					err += dx;
				}
			}
		}
	}

	//带深度插值的任意直线绘制算法(SDF)
	void drawBuffLineSDF(float x1p, float y1p, float x2p, float y2p, float z1, float z2, uint16_t color, bool cover,
		float r) {
		int16_t x1 = x1p;        int16_t y1 = y1p;        int16_t x2 = x2p;        int16_t y2 = y2p;
		uint16_t dr = ceil(r) + 1;
		const uint16_t bias = 200;
		const float invis_thick = 0.3;
		if (abs(y2 - y1) > abs(x2 - x1)) {
			this->swap(x1, y1);
			this->swap(x2, y2);
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
				this->swap(z1, z2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			int16_t x_temp = x1;
			int16_t y_temp = y1;
			for (; x1 <= (x2 + dr); ++x1) {
				if (this->inSide2(y1, x1)) {
					float t = (float)(x2 - x1) / (float)dx;
					float zp = z1 * t + z2 * (1 - t);
					uint16_t z = (1.0f - zp) * 32767.0;
					if ((z + bias) >= this->zbuff->readPixel(y1 + this->sx, x1 + this->sy)) {
						this->zbuff->drawPixel(y1 + this->sx, x1 + this->sy, z);
						for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
							alphablend(py, x1,
								fmaxf(fminf(0.5f - capsuleSDF(py, x1, x1p, y1p, x2p, y2p, r), 1.0f), 0.0f),
								color);
						}
					}
					else if (!cover && ((x1) % 5 < 3))//是否绘制隐藏线。绘制时随机错位。
						for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
							alphablend(py, x1,
								fmaxf(fminf(0.5f - capsuleSDF(py, x1, x1p, y1p, x2p, y2p, invis_thick), 1.0f),
									0.0f),
								colorHSV(0.2, 1, 0.45));
						}
				}
				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
			y1 = y_temp;
			for (x1 = x_temp; x1 >= (x_temp - dr); x1--) {
				if (this->inSide2(y1, x1)) {
					float t = (float)(x2 - x1) / (float)dx;
					float zp = z1 * t + z2 * (1 - t);
					uint16_t z = (1.0f - zp) * 32767.0;
					if ((z + bias) >= this->zbuff->readPixel(y1 + this->sx, x1 + this->sy)) {
						this->zbuff->drawPixel(y1 + this->sx, x1 + this->sy, z);
						for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
							alphablend(py, x1,
								fmaxf(fminf(0.5f - capsuleSDF(py, x1, x1p, y1p, x2p, y2p, r), 1.0f), 0.0f),
								color);
						}
					}
					else if (!cover && ((x1) % 5 < 3))//是否绘制隐藏线。绘制时随机错位。
						for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
							alphablend(py, x1,
								fmaxf(fminf(0.5f - capsuleSDF(py, x1, x1p, y1p, x2p, y2p, invis_thick), 1.0f),
									0.0f),
								colorHSV(0.2, 1, 0.45));
						}
				}
				err -= dy;
				if (err < 0) {
					y1 -= ystep;
					err += dx;
				}
			}
		}
		else {
			if (x1 > x2) {
				this->swap(x1, x2);
				this->swap(y1, y2);
				this->swap(z1, z2);
			}
			int16_t dx = x2 - x1;
			int16_t dy = abs(y2 - y1);
			int16_t err = dx >> 1;
			int16_t ystep = y1 < y2 ? 1 : -1;
			int16_t x_temp = x1;
			int16_t y_temp = y1;
			for (; x1 <= (x2 + dr); ++x1) {
				if (this->inSide2(x1, y1)) {
					float t = (float)(x2 - x1) / (float)dx;
					float zp = z1 * t + z2 * (1 - t);
					uint16_t z = (1.0f - zp) * 32767.0;
					if ((z + bias) >= this->zbuff->readPixel(x1 + this->sx, y1 + this->sy)) {
						this->zbuff->drawPixel(x1 + this->sx, y1 + this->sy, z);
						for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
							alphablend(x1, py,
								fmaxf(fminf(0.5f - capsuleSDF(x1, py, x1p, y1p, x2p, y2p, r), 1.0f), 0.0f),
								color);
						}
					}
					else if (!cover && ((x1) % 5 < 3))//是否绘制隐藏线。绘制时随机错位。
						for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
							alphablend(x1, py,
								fmaxf(fminf(0.5f - capsuleSDF(x1, py, x1p, y1p, x2p, y2p, invis_thick), 1.0f),
									0.0f),
								colorHSV(0.2, 1, 0.45));
						}
				}
				err -= dy;
				if (err < 0) {
					y1 += ystep;
					err += dx;
				}
			}
			y1 = y_temp;
			for (x1 = x_temp; x1 >= (x_temp - dr); x1--) {
				if (this->inSide2(x1, y1)) {
					float t = (float)(x2 - x1) / (float)dx;
					float zp = z1 * t + z2 * (1 - t);
					uint16_t z = (1.0f - zp) * 32767.0;
					if ((z + bias) >= this->zbuff->readPixel(x1 + this->sx, y1 + this->sy)) {
						this->zbuff->drawPixel(x1 + this->sx, y1 + this->sy, z);
						for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
							alphablend(x1, py,
								fmaxf(fminf(0.5f - capsuleSDF(x1, py, x1p, y1p, x2p, y2p, r), 1.0f), 0.0f),
								color);
						}
					}
					else if (!cover && ((x1) % 5 < 3))//是否绘制隐藏线。绘制时随机错位。
						for (int16_t py = y1 - dr; py <= (y1 + dr); py++) {
							alphablend(x1, py,
								fmaxf(fminf(0.5f - capsuleSDF(x1, py, x1p, y1p, x2p, y2p, invis_thick), 1.0f),
									0.0f),
								colorHSV(0.2, 1, 0.45));
						}
				}
				err -= dy;
				if (err < 0) {
					y1 -= ystep;
					err += dx;
				}
			}
		}
	}
};
//TFT屏幕和墨水屏使用不同的定义
#ifdef Epaper_Display
TFT_eSPI Virtual_Display; //给深度数据存储使用的虚拟Sprite
class E512W3DWindowManager {
public:
	E512W3DWindow* ws[32];
	uint16_t wsize = 0;
	uint16_t width = 0;
	uint16_t height = 0;
	M5EPD_Canvas* tft_es_buff;
	TFT_eSprite* zbuff;
	uint16_t fixed_milli_time = 33;
	E512W3DWindowManager() {}
	void begin() {
		this->tft_es_buff = new M5EPD_Canvas(&M5.EPD);
		this->tft_es_buff->createCanvas(this->width, this->height);
		this->zbuff = new TFT_eSprite(&Virtual_Display); //给深度数据存储使用的虚拟Sprite
		this->zbuff->createSprite(this->width, this->height);
		for (int i = 0; i < this->wsize; ++i) {
			this->ws[i]->buff = this->tft_es_buff;
			this->ws[i]->zbuff = this->zbuff;
			this->ws[i]->screen_width = this->width;
			this->ws[i]->screen_height = this->height;
		}
	}
	void add(E512W3DWindow& w) {
		if (this->wsize < 32) {
			this->ws[this->wsize] = &w;
			this->wsize += 1;
		}
	}
	void fixedDrawWait(m5epd_update_mode_t mode) {
		while (millis() - this->prev_time < this->fixed_milli_time) { delay(1); }
		this->prev_time = millis();
		this->buffUpdate();
		this->screenDraw(mode);
	}
	void fixedDraw(m5epd_update_mode_t mode) {
		uint64_t t = millis();
		if (t - this->prev_time >= this->fixed_milli_time) {
			this->buffUpdate();
			this->screenDraw(mode);
			this->prev_time = t;
		}
	}
	void draw(m5epd_update_mode_t mode) {
		this->prev_time = millis();
		this->buffUpdate();
		this->screenDraw(mode);
	}
	bool isFixedTime() {
		return millis() - this->prev_time >= this->fixed_milli_time;
	}
	uint64_t prev_time = 0;
	void screenDraw(m5epd_update_mode_t mode)
	{
		this->tft_es_buff->pushCanvas(0, 0, mode);
	}
private:
	void buffUpdate()
	{
		this->tft_es_buff->fillCanvas(0);
		this->zbuff->fillSprite(0); //
		for (int i = 0; i < this->wsize; ++i)
		{
			E512W3DWindow& w = *this->ws[i];
			w.draw();
		}
	}
};
#else

class E512W3DWindowManager {
public:
	E512W3DWindow* ws[32];
	uint16_t wsize = 0;
	uint16_t width = 0;
	uint16_t height = 0;
	TFT_eSprite* tft_es_buff;
	TFT_eSprite* zbuff;
	// TFT_eSprite* zbuff_show;
	uint16_t fixed_milli_time = 33;

	E512W3DWindowManager() {}

	void begin() {
		this->tft_es_buff = new TFT_eSprite(&M5.Lcd);
		this->tft_es_buff->setColorDepth(16);
		this->tft_es_buff->createSprite(this->width, this->height);
		this->zbuff = new TFT_eSprite(&M5.Lcd);
		this->zbuff->setColorDepth(16);
		this->zbuff->createSprite(this->width, this->height);
		// this->zbuff_show = new TFT_eSprite(&M5.Lcd);
		// this->zbuff_show->setColorDepth(16);
		// this->zbuff_show->createSprite(this->width, this->height);
		for (int i = 0; i < this->wsize; ++i) {
			this->ws[i]->buff = this->tft_es_buff;
			this->ws[i]->zbuff = this->zbuff;
			// this->ws[i]->zbuff_show = this->zbuff_show;
			this->ws[i]->screen_width = this->width;
			this->ws[i]->screen_height = this->height;
		}
	}

	void add(E512W3DWindow& w) {
		if (this->wsize < 32) {
			this->ws[this->wsize] = &w;
			this->wsize += 1;
		}
	}

	void fixedDrawWait() {
		while (millis() - this->prev_time < this->fixed_milli_time) { delay(1); }
		this->prev_time = millis();
		this->buffUpdate();
		this->screenDraw();
	}

	void fixedDraw() {
		uint64_t t = millis();
		if (t - this->prev_time >= this->fixed_milli_time) {
			this->buffUpdate();
			this->screenDraw();
			this->prev_time = t;
		}
	}

	void draw() {
		this->prev_time = millis();
		this->buffUpdate();
		this->screenDraw();
	}

	bool isFixedTime() {
		return millis() - this->prev_time >= this->fixed_milli_time;
	}

	uint64_t prev_time = 0;

	void screenDraw() {
		this->tft_es_buff->pushSprite(0, 0);
		// this->zbuff_show->pushSprite(0, 0);
	}

private:
	void buffUpdate() {
		this->tft_es_buff->fillSprite(0);
		this->zbuff->fillSprite(0);            //
		// this->zbuff_show->fillSprite(0);
		for (int i = 0; i < this->wsize; ++i) {
			E512W3DWindow& w = *this->ws[i];
			w.draw();
		}
	}
};

#endif



