/*
/   改动：增加渲染类型；增加Edge类
/
/
*/
#pragma once

#include "E512W3DUtilsX.hpp"

#define DOUBLE

#ifdef DOUBLE
#define FPOINT double
#else
#define FPOINT float
#endif

#ifdef Epaper_Display
// uint8_t color4bpp (uint16_t r, uint16_t g, uint16_t b) { return 16*(0.299*r+0.578*g+0.114*b)/255.0; } //底色为黑
uint8_t color4bpp(uint16_t r, uint16_t g, uint16_t b) { return 15 - 15 * (0.299 * r + 0.578 * g + 0.114 * b) / 255.0; } //底色为白
uint8_t color565(uint16_t r, uint16_t g, uint16_t b) { return color4bpp(r, g, b); }//底色为白
uint8_t colorHSL(float H, float S, float L) { return 15 * L; }
uint8_t colorHSV(float H, float S, float V) { return 15 * V; }
#else
uint16_t color565(uint16_t r, uint16_t g, uint16_t b) { return ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3); }
//uint16_t color565abs (uint16_t r, uint16_t g, uint16_t b) { return ((r)<<11) | ((g)<<5) | (b); }

// uint16_t color555 (uint16_t r, uint16_t g, uint16_t b) { return ((r>>3)<<10) | ((g>>3)<<5) | (b>>3); }
float Hue2RGB(float v1, float v2, float vH)
{
	if (vH < 0) vH += 1;
	if (vH > 1) vH -= 1;
	if (6.0 * vH < 1) return v1 + (v2 - v1) * 6.0 * vH;
	if (2.0 * vH < 1) return v2;
	if (3.0 * vH < 2) return v1 + (v2 - v1) * ((2.0 / 3.0) - vH) * 6.0;
	return (v1);
}

uint16_t colorHSL(float H, float S, float L) {
	uint16_t R, G, B;
	float var_1, var_2;
	if (S == 0)                       //HSL values = 0 ÷ 1
	{
		R = L * 255.0;                   //RGB results = 0 ÷ 255
		G = L * 255.0;
		B = L * 255.0;
	}
	else {
		if (L < 0.5) var_2 = L * (1 + S);//L=1.0对应纯白
		else var_2 = (L + S) - (S * L);//L=1.0对应纯白
		var_1 = 2.0 * L - var_2;
		R = 255.0 * Hue2RGB(var_1, var_2, H + (1.0 / 3.0));
		G = 255.0 * Hue2RGB(var_1, var_2, H);
		B = 255.0 * Hue2RGB(var_1, var_2, H - (1.0 / 3.0));
	}
	return ((R >> 3) << 11) | ((G >> 2) << 5) | (B >> 3);
}

uint16_t colorHSV(float H, float S, float V) {
	uint8_t R, G, B;
	if (S == 0) {
		R = V * 255.0;
		G = V * 255.0;
		B = V * 255.0;
	}
	else {
		H = max((float)0.0, H);
		H = min((float)1.0, H);
		uint8_t hi = floor(H * 6.0);
		float f = H * 6.0 - hi;
		float p = V * (1 - S);
		float q = V * (1 - f * S);
		float t = V * (1 - (1 - f) * S);
		switch (hi) {
		case 0:
			R = 255.0 * V;
			G = 255.0 * t;
			B = 255.0 * p;
			break;
		case 1:
			R = 255.0 * q;
			G = 255.0 * V;
			B = 255.0 * p;
			break;
		case 2:
			R = 255.0 * p;
			G = 255.0 * V;
			B = 255.0 * t;
			break;
		case 3:
			R = 255.0 * p;
			G = 255.0 * q;
			B = 255.0 * V;
			break;
		case 4:
			R = 255.0 * t;
			G = 255.0 * p;
			B = 255.0 * V;
			break;
		case 5:
			R = 255.0 * V;
			G = 255.0 * p;
			B = 255.0 * q;
			break;
		default:
			break;
		}
	}
	return ((R >> 3) << 11) | ((G >> 2) << 5) | (B >> 3);
}
//---------------------------------------------------------------------------
#endif


//若引用的其他文件未实现min或max，则在此实现。若已实现，则注释此处
// #ifndef min
// // Return minimum of two numbers, may already be defined
// #define min(a,b) (((a) < (b)) ? (a) : (b))
// #endif
// #ifndef max
// // Return minimum of two numbers, may already be defined
// #define max(a,b) (((a) > (b)) ? (a) : (b))
// #endif


template <class T>
class E512Array {
private:
	uint32_t array_size = 0;
	uint32_t array_capacity = 1;
public:
	T* a;

	E512Array() { this->a = new T[1]; }
	E512Array(uint32_t sz) {
		this->a = new T[sz];
		this->array_capacity = sz;
	}
	E512Array(uint32_t sz, T t) {
		this->a = new T[sz];
		this->array_size = sz;
		this->array_capacity = sz;
		for (int i = 0; i < sz; ++i) { this->a[i] = t; }
	}

	~E512Array() { delete[] this->a; }

	uint32_t size() { return this->array_size; }
	uint32_t capacity() { return this->array_capacity; }

	void resize(uint32_t sz, T c = T()) {
		while (sz < this->array_size) { this->pop_back(); }
		while (sz > this->array_size) { this->push_back(c); }
	}

	void reserve(uint32_t sz) {
		if (sz < this->array_capacity) { return; }
		this->array_capacity = sz;
		T* a = new T[this->array_capacity];
		for (int i = 0; i < min(this->array_size, this->array_capacity); ++i) { a[i] = this->a[i]; }
		delete[] this->a;
		this->a = a;
		this->array_size = min(this->array_size, this->array_capacity);
	}

	void shrink_to_fit() {
		this->array_capacity = this->array_size;
		T* a = new T[this->array_capacity];
		for (int i = 0; i < this->array_size; ++i) { a[i] = this->a[i]; }
		delete[] this->a;
		this->a = a;
	}

	template <class... Args>
	void emplace_back(Args... args) {
		if (this->array_size + 1 > this->array_capacity) {
			this->array_capacity *= 2;
			T* a = new T[this->array_capacity];
			for (int i = 0; i < this->array_size; ++i) { a[i] = this->a[i]; }
			a[this->array_size] = T(args...);
			delete[] this->a;
			this->a = a;
			this->array_size += 1;
		}
		else {
			this->a[this->array_size] = T(args...);
			this->array_size += 1;
		}
	}
	void push_back(T t) { this->emplace_back(t); }

	void pop_back() {
		if (this->array_size > 0) { this->array_size -= 1; }
	}

	void erase_index(int index) {
		uint32_t tcnt = 0;
		for (uint32_t i = 0; i < this->array_size; ++i) {
			if (i != index) {
				this->a[tcnt] = this->a[i];
				tcnt += 1;
			}
		}
		this->array_size = tcnt;
	}

	void erase_value(T t) {
		uint32_t tcnt = 0;
		for (uint32_t i = 0; i < this->array_size; ++i) {
			if (this->a[i] != t) {
				this->a[tcnt] = this->a[i];
				tcnt += 1;
			}
		}
		this->array_size = tcnt;
	}

	T& front() { return this->a[0]; }
	T& back() { return this->a[this->array_size - 1]; }

	E512Array(const E512Array& t) {
		T* a = new T[t.array_capacity];
		for (int i = 0; i < t.array_size; ++i) { a[i] = t.a[i]; }
		this->array_size = t.array_size;
		this->array_capacity = t.array_capacity;
		this->a = a;
	}

	E512Array& operator = (const E512Array& t) {
		T* a = new T[t.array_capacity];
		for (int i = 0; i < t.array_size; ++i) { a[i] = t.a[i]; }
		this->array_size = t.array_size;
		this->array_capacity = t.array_capacity;
		delete[] this->a;
		this->a = a;
		return *this;
	}

	// indexer
	T& operator [] (uint32_t i) { return this->a[i]; }

	// range based for
	T* begin() { return &this->a[0]; }
	T* end() { return &this->a[this->array_size]; }
};

struct Vector2 {
public:
	FPOINT x, y;
	Vector2() { this->x = 0; this->y = 0; }
	Vector2(FPOINT t) { this->x = t; this->y = t; }
	Vector2(FPOINT x, FPOINT y) { this->x = x; this->y = y; }
	//Vector2 (Vector3 v) { this->x = v.x; this->y = v.y; }
	Vector2 operator + (const Vector2& t) const { return Vector2(this->x + t.x, this->y + t.y); }
	Vector2 operator - (const Vector2& t) const { return Vector2(this->x - t.x, this->y - t.y); }
	Vector2 operator * (const Vector2& t) const { return Vector2(this->x * t.x, this->y * t.y); }
	Vector2 operator / (const Vector2& t) const { return Vector2(this->x / t.x, this->y / t.y); }
	Vector2 operator + (const FPOINT& t) const { return Vector2(this->x + t, this->y + t); }
	Vector2 operator - (const FPOINT& t) const { return Vector2(this->x - t, this->y - t); }
	Vector2 operator * (const FPOINT& t) const { return Vector2(this->x * t, this->y * t); }
	Vector2 operator / (const FPOINT& t) const { return Vector2(this->x / t, this->y / t); }
	bool operator == (const Vector2& t) const { return this->x == t.x && this->y == t.y; }
};
struct Vector3 {
public:
	FPOINT x, y, z;
	Vector3() { this->x = 0; this->y = 0; this->z = 0; }
	Vector3(FPOINT t) { this->x = t; this->y = t; this->z = t; }
	Vector3(Vector2 t, FPOINT z) { this->x = t.x; this->y = t.y; this->z = z; }
	Vector3(FPOINT x, Vector2 t) { this->x = x; this->y = t.x; this->z = t.y; }
	Vector3(FPOINT x, FPOINT y, FPOINT z) { this->x = x; this->y = y; this->z = z; }
	static Vector3 normalize(Vector3 v) {
		FPOINT d = sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
		if (d == 0) { return Vector3(0.0f, 0.0f, 0.0f); }
		return v / d;
	}
	static Vector3 cross(const Vector3 a, const Vector3 b) { return Vector3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
	static FPOINT dot(Vector3 a, Vector3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
	Vector2 head() { return Vector2(x, y); } //返回二维向量
	Vector3 operator + (const Vector3& t) const { return Vector3(this->x + t.x, this->y + t.y, this->z + t.z); }
	Vector3 operator - (const Vector3& t) const { return Vector3(this->x - t.x, this->y - t.y, this->z - t.z); }
	Vector3 operator * (const Vector3& t) const { return Vector3(this->x * t.x, this->y * t.y, this->z * t.z); }
	Vector3 operator / (const Vector3& t) const { return Vector3(this->x / t.x, this->y / t.y, this->z / t.z); }
	Vector3 operator + (const FPOINT& t) const { return Vector3(this->x + t, this->y + t, this->z + t); }
	Vector3 operator - (const FPOINT& t) const { return Vector3(this->x - t, this->y - t, this->z - t); }
	Vector3 operator * (const FPOINT& t) const { return Vector3(this->x * t, this->y * t, this->z * t); }
	Vector3 operator / (const FPOINT& t) const { return Vector3(this->x / t, this->y / t, this->z / t); }
	bool operator == (const Vector3& t) const { return this->x == t.x && this->y == t.y && this->z == t.z; }
};
struct Matrix4x4 {
public:
	FPOINT m[4][4] = {
			{0.0f, 0.0f, 0.0f, 0.0f},
			{0.0f, 0.0f, 0.0f, 0.0f},
			{0.0f, 0.0f, 0.0f, 0.0f},
			{0.0f, 0.0f, 0.0f, 0.0f}
	};
	Matrix4x4() {}
	Matrix4x4(FPOINT a[]) {
		for (int i = 0; i < 4; ++i) {
			for (int j = 0; j < 4; ++j) {
				this->m[i][j] = a[i * 4 + j];
			}
		}
	}
	static FPOINT radian(FPOINT d) { return d * 0.01745329251f; }
	static Matrix4x4 identity() {
		FPOINT a[] = {
				1.0f, 0.0f, 0.0f, 0.0f,
				0.0f, 1.0f, 0.0f, 0.0f,
				0.0f, 0.0f, 1.0f, 0.0f,
				0.0f, 0.0f, 0.0f, 1.0f
		};
		return Matrix4x4(a);
	}

	static Matrix4x4 mul(Matrix4x4 a, Matrix4x4 b) {
		Matrix4x4 r;
		for (int i = 0; i < 4; ++i) {
			for (int j = 0; j < 4; ++j) {
				for (int k = 0; k < 4; ++k) {
					r.m[i][j] += a.m[i][k] * b.m[k][j];
				}
			}
		}
		return r;
	}

	static Vector3 mul(Vector3 v, Matrix4x4 m) {
		FPOINT d = v.x * m.m[0][3] + v.y * m.m[1][3] + v.z * m.m[2][3] + 1.0f * m.m[3][3];
		Vector3 r = {
				v.x * m.m[0][0] + v.y * m.m[1][0] + v.z * m.m[2][0] + 1.0f * m.m[3][0],
				v.x * m.m[0][1] + v.y * m.m[1][1] + v.z * m.m[2][1] + 1.0f * m.m[3][1],
				v.x * m.m[0][2] + v.y * m.m[1][2] + v.z * m.m[2][2] + 1.0f * m.m[3][2],
		};

		if (d > 0) {
			r.x /= d;
			r.y /= d;
			r.z /= d;
		}
		return r;
	}

	static Matrix4x4 projectionMatrix(FPOINT w, FPOINT h) {
		Matrix4x4 r;
		FPOINT aspect = w / h;
		FPOINT cfov = Matrix4x4::radian(45.0);
		FPOINT cnear = 4.0f;
		FPOINT cfar = 1000.0f;
		FPOINT y = 1.0f / tan(cfov * 0.5f);
		FPOINT x = y / aspect;
		FPOINT z = cfar / (cnear - cfar);
		r.m[0][0] = x;
		r.m[1][1] = y;
		r.m[2][2] = z;
		r.m[2][3] = -1.0f;
		r.m[3][2] = z * cnear;
		return r;
	}

	static Matrix4x4 orthoMatrix(FPOINT w, FPOINT h, FPOINT size) {
		Matrix4x4 r;
		FPOINT left = -w * size;
		FPOINT right = w * size;

		FPOINT top = h * size;
		FPOINT bottom = -h * size;

		FPOINT cnear = 4.0f;
		FPOINT cfar = 1000.0f;
		r.m[0][0] = 2.0f / (right - left);
		r.m[1][1] = 2.0f / (top - bottom);
		r.m[2][2] = -2.0f / (cnear - cfar);
		r.m[3][0] = -((right + left) / (right - left));
		r.m[3][1] = -((top + bottom) / (top - bottom));
		r.m[3][2] = ((cfar + cnear) / (cfar - cnear));

		r.m[3][3] = 1.0f;

		return r;
	}
	static Matrix4x4 screenMatrix(FPOINT w, FPOINT h) {
		Matrix4x4 r;
		FPOINT hcx = w / 2;
		FPOINT hcy = h / 2;
		r.m[0][0] = hcx;
		r.m[1][1] = -hcy;
		r.m[2][2] = 1.0f;
		r.m[3][0] = hcx; r.m[3][1] = hcy; r.m[3][3] = 1.0f;
		return r;
	}

	static Matrix4x4 projscreenMatrix(FPOINT w, FPOINT h) {
		Matrix4x4 r;
		r.m[0][0] = 1.0f; r.m[1][1] = 1.0f; r.m[2][2] = 1.0f; r.m[3][3] = 1.0f;
		r = Matrix4x4::mul(r, Matrix4x4::projectionMatrix(w, h));
		r = Matrix4x4::mul(r, Matrix4x4::screenMatrix(w, h));
		return r;
	}
	static Matrix4x4 orthoscreenMatrix(FPOINT w, FPOINT h, FPOINT size) {
		Matrix4x4 r;
		r.m[0][0] = 1.0f; r.m[1][1] = 1.0f; r.m[2][2] = 1.0f; r.m[3][3] = 1.0f;
		r = Matrix4x4::mul(r, Matrix4x4::orthoMatrix(w, h, size));
		r = Matrix4x4::mul(r, Matrix4x4::screenMatrix(w, h));
		return r;
	}

	static Matrix4x4 moveMatrix(Vector3 v) {
		Matrix4x4 r = Matrix4x4::identity();
		r.m[3][0] = v.x;
		r.m[3][1] = v.y;
		r.m[3][2] = v.z;
		return r;
	}
	static Matrix4x4 rotMatrix(Vector3 v) {
		Matrix4x4 r = Matrix4x4::identity();
		Matrix4x4 t;
		FPOINT x = Matrix4x4::radian(v.x);
		FPOINT y = Matrix4x4::radian(v.y);
		FPOINT z = Matrix4x4::radian(v.z);

		t = Matrix4x4::identity();
		t.m[1][1] = cos(x);
		t.m[1][2] = sin(x);
		t.m[2][1] = -sin(x);
		t.m[2][2] = cos(x);
		r = Matrix4x4::mul(r, t);

		t = Matrix4x4::identity();
		t.m[0][0] = cos(y);
		t.m[0][2] = -sin(y);
		t.m[2][0] = sin(y);
		t.m[2][2] = cos(y);
		r = Matrix4x4::mul(r, t);

		t = Matrix4x4::identity();
		t.m[0][0] = cos(z);
		t.m[0][1] = sin(z);
		t.m[1][0] = -sin(z);
		t.m[1][1] = cos(z);
		r = Matrix4x4::mul(r, t);

		return r;
	}

	static Matrix4x4 scaleMatrix(Vector3 v) {
		Matrix4x4 r = Matrix4x4::identity();
		r.m[0][0] = v.x;
		r.m[1][1] = v.y;
		r.m[2][2] = v.z;
		return r;
	}
};

struct Face {
	uint32_t a, b, c;
	Face() {};
	Face(uint32_t a, uint32_t b, uint32_t c) { this->a = a; this->b = b; this->c = c; }
};
enum EdgeType
{
	Normal,
	Border,
	Crease,
	Contour,
	Silhouette,
};
struct Edge {
	uint32_t va = 0, vb = 0; //边的两个顶点编号，从小到大排列
	uint32_t fa = 0, fb = 0;//边接触的面编号，从小到大排列（假设至多接触两个面）//之前忘记加了，相当于fb可能未初始化
	uint8_t n = 0; //接触的面个数
	uint8_t edge_type = EdgeType::Normal;
	Edge() { va = 0; vb = 0; fa = 0; fb = 0; n = 0; };
	Edge(uint32_t va, uint32_t vb)
	{
		if (va < vb) { this->va = va; this->vb = vb; }
		else { this->va = vb; this->vb = va; }
	}
};
struct edge_face {
	uint32_t edge;
	uint32_t face;
};
struct Mesh {
public:
	E512Array<Vector3> vertexs;
	E512Array<Face> faces;
	E512Array<Edge> edges; //
	E512Array<Vector2> uv_vertexs;
	E512Array<Face> uv_faces;
	std::map<int, E512Array<edge_face>> edgemap;

	Mesh() { edgemap.clear(); };
	~Mesh() {};

	void addVertex(FPOINT x, FPOINT y, FPOINT z) { this->addVertex(Vector3(x, y, z)); }
	void addVertex(Vector3 v) {
		this->vertexs.emplace_back(v);
		// this->tvertexs.emplace_back(v);
	}

	void addFace(uint32_t a, uint32_t b, uint32_t c) { this->addFace(Face(a, b, c)); }
	void addFace(Face f) {
		this->faces.emplace_back(f);
	}

	void addEdge(uint32_t va, uint32_t vb, uint32_t f) { addEdge(Edge(va, vb), f); } //添加边时，传入两个顶点编号及面编号
	void addEdge(Edge e, uint32_t f) {
		uint32_t index = e.va + e.vb;
		auto iter = edgemap.find(index);

		if (iter == edgemap.end()) {// 全新的index，只可能是一条全新的边，添加到集合，且fa设为f，把（edge_index,face)信息添加到index键中
			e.fa = f;
			e.n = 1;
			this->edges.emplace_back(e);
			//生成（edge_index,face)信息
			edge_face edge_face_pair;
			edge_face_pair.edge = edges.size() - 1;
			edge_face_pair.face = f;
			//添加信息到键index
			E512Array<edge_face> index_info;
			index_info.emplace_back(edge_face_pair);
			edgemap[index] = index_info;
		}
		else {//两种情况：另一组无关的va+vb也等于此index；或，出现了第二个包含此（va,vb）的面
			auto& index_info = iter->second;
			for (auto& info : index_info)
			{
				if (this->edges[info.edge].va == e.va) {//出现了第二个包含此（va, vb）的面
					if (f > this->edges[info.edge].fa) {
						this->edges[info.edge].fb = f;
						this->edges[info.edge].n++;
					}
					else {
						this->edges[info.edge].fb = this->edges[info.edge].fa;
						this->edges[info.edge].fa = f;
						this->edges[info.edge].n++;
					}
					return;
				}
			}
			//另一组无关的va+vb也等于此index；
			e.fa = f;
			e.n = 1;
			this->edges.emplace_back(e);
			//生成（edge_index,face)信息
			edge_face edge_face_pair;
			edge_face_pair.edge = edges.size() - 1;
			edge_face_pair.face = f;
			//添加信息到键index
			index_info.emplace_back(edge_face_pair);
		}
	}
	//void addEdge(Edge e, uint32_t f) {
	//    if (this->edges.size() > 0)
	//        for (int i = this->edges.size() - 1; i >= 0; i--) { //遍历查重，速度很慢
	//            if ((e.va == this->edges[i].va) && (e.vb == this->edges[i].vb)) //已存在此边，但不包含此面
	//            {
	//                if (f > this->edges[i].fa) {
	//                    this->edges[i].fb = f;
	//                    this->edges[i].n++;
	//                }
	//                else {
	//                    this->edges[i].fb = this->edges[i].fa;
	//                    this->edges[i].fa = f;
	//                    this->edges[i].n++;
	//                }
	//                return;
	//            }
	//        }
	//    // 全新的边，添加到集合，且fa设为f
	//    e.fa = f;
	//    e.n = 1;
	//    this->edges.emplace_back(e);
	//}
	void addVertexUV(FPOINT x, FPOINT y) { this->addVertexUV(Vector2(x, y)); }
	void addVertexUV(Vector2 v) {
		this->uv_vertexs.emplace_back(v);
	}
	void addFaceUV(uint32_t a, uint32_t b, uint32_t c) { this->addFaceUV(Face(a, b, c)); }
	void addFaceUV(Face f) {
		this->uv_faces.emplace_back(f);
	}
};

struct Texture {
	uint32_t width = 0;
	uint32_t height = 0;
	uint16_t* pixels;
	Texture() {};
	Texture(uint32_t width, uint32_t height, uint16_t* pixels) {
		this->width = width;
		this->height = height;
		this->pixels = pixels;
	}
	uint32_t getColor(FPOINT u, FPOINT v) {
		const uint32_t u16i = (uint32_t)(this->width * u) % this->width;
		const uint32_t v16i = (uint32_t)(this->height * (1.0 - v)) % this->height;
		return this->pixels[v16i * this->width + u16i];
	}
};

enum RenderType {
	WireFrame,
	Edges, //
	EdgesZ,
	Test,
	PolygonNormal,
	Zbuff,
	PolygonColor,
	Vertex, //
	VertexZ, //
	PolygonTexture,
	PolygonTextureDoubleFace,
	Hide,
	None,
	// Line,
};

struct Object3D {
public:
	Vector3 position;
	Vector3 rotation;
	Vector3 scale = Vector3(1.0f, 1.0f, 1.0f);
	Mesh* mesh = NULL;
	uint16_t color = 65535;
	uint16_t render_type = RenderType::WireFrame;
	Object3D* parent;
	E512Array<Object3D*> child;
	Texture* texture;

	Object3D() {};

	void setParent(Object3D& o) {
		this->parent = &o;
		o.child.emplace_back(this);
	}
	void addChild(Object3D& o) {
		o.parent = this;
		this->child.emplace_back(&o);
	}
};
